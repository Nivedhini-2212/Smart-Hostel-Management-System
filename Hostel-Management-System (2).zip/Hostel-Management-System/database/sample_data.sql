USE hostel_management;

-- =========================================================
-- 1. USERS
-- =========================================================

INSERT INTO users (username, password, role) VALUES
('admin', 'Admin@123', 'ADMIN'),
('warden1', 'Warden@123', 'WARDEN'),
('warden2', 'Warden@456', 'WARDEN'),
('student1', 'Student@123', 'STUDENT'),
('student2', 'Student@456', 'STUDENT'),
('student3', 'Student@789', 'STUDENT'),
('student4', 'Student@111', 'STUDENT'),
('student5', 'Student@222', 'STUDENT');


-- =========================================================
-- 2. STUDENTS
-- =========================================================

INSERT INTO students
(user_id, register_no, name, department, year, gender, phone, email,
 parent_name, parent_phone, address, admission_date, status)
VALUES
(4, 'IT2024001', 'Arun Kumar', 'Information Technology', 3, 'Male',
 '9876543210', 'arun@example.com',
 'Ramesh Kumar', '9876500011', 'Erode, Tamil Nadu', '2024-07-15', 'ACTIVE'),

(5, 'IT2024002', 'Priya Sharma', 'Information Technology', 3, 'Female',
 '9876543211', 'priya@example.com',
 'Suresh Sharma', '9876500012', 'Salem, Tamil Nadu', '2024-07-15', 'ACTIVE'),

(6, 'CSE2024003', 'Karthik Raj', 'Computer Science Engineering', 3, 'Male',
 '9876543212', 'karthik@example.com',
 'Rajendran', '9876500013', 'Coimbatore, Tamil Nadu', '2024-07-16', 'ACTIVE'),

(7, 'ECE2025004', 'Divya S', 'Electronics and Communication Engineering', 2, 'Female',
 '9876543213', 'divya@example.com',
 'Selvam', '9876500014', 'Madurai, Tamil Nadu', '2025-07-14', 'ACTIVE'),

(8, 'IT2025005', 'Rahul M', 'Information Technology', 2, 'Male',
 '9876543214', 'rahul@example.com',
 'Mahesh', '9876500015', 'Tiruppur, Tamil Nadu', '2025-07-14', 'ACTIVE');


-- =========================================================
-- 3. HOSTELS
-- =========================================================

INSERT INTO hostels
(hostel_name, hostel_type, location, total_rooms, status)
VALUES
('A Block Hostel', 'BOYS', 'North Campus', 10, 'ACTIVE'),
('B Block Hostel', 'GIRLS', 'South Campus', 10, 'ACTIVE');


-- =========================================================
-- 4. ROOMS
-- =========================================================

INSERT INTO rooms
(hostel_id, room_number, floor, capacity, status)
VALUES
(1, 'A101', 1, 2, 'FULL'),
(1, 'A102', 1, 2, 'AVAILABLE'),
(1, 'A201', 2, 2, 'FULL'),
(1, 'A202', 2, 2, 'AVAILABLE'),

(2, 'B101', 1, 2, 'FULL'),
(2, 'B102', 1, 2, 'AVAILABLE'),
(2, 'B201', 2, 2, 'AVAILABLE'),
(2, 'B202', 2, 2, 'AVAILABLE');


-- =========================================================
-- 5. BEDS
-- =========================================================

INSERT INTO beds
(room_id, bed_number, status)
VALUES
-- A101
(1, 'A1', 'OCCUPIED'),
(1, 'A2', 'OCCUPIED'),

-- A102
(2, 'A1', 'AVAILABLE'),
(2, 'A2', 'AVAILABLE'),

-- A201
(3, 'A1', 'OCCUPIED'),
(3, 'A2', 'OCCUPIED'),

-- A202
(4, 'A1', 'AVAILABLE'),
(4, 'A2', 'AVAILABLE'),

-- B101
(5, 'B1', 'OCCUPIED'),
(5, 'B2', 'OCCUPIED'),

-- B102
(6, 'B1', 'AVAILABLE'),
(6, 'B2', 'AVAILABLE'),

-- B201
(7, 'B1', 'AVAILABLE'),
(7, 'B2', 'AVAILABLE'),

-- B202
(8, 'B1', 'AVAILABLE'),
(8, 'B2', 'AVAILABLE');


-- =========================================================
-- 6. ROOM ALLOCATIONS
-- =========================================================

INSERT INTO room_allocations
(student_id, room_id, bed_id, allocation_date, vacate_date, status)
VALUES
(1, 1, 1, '2026-06-10', NULL, 'ACTIVE'),
(3, 1, 2, '2026-06-10', NULL, 'ACTIVE'),

(1, 3, 5, '2025-06-15', '2026-06-09', 'VACATED'),
(3, 3, 6, '2025-06-15', '2026-06-09', 'VACATED'),

(2, 5, 9, '2026-06-12', NULL, 'ACTIVE'),
(4, 5, 10, '2026-06-12', NULL, 'ACTIVE');


-- =========================================================
-- 7. FEES
-- =========================================================

INSERT INTO fees
(student_id, fee_type, amount, due_date, paid_date, status)
VALUES
(1, 'Hostel Fee', 25000.00, '2026-07-15', '2026-07-10', 'PAID'),
(1, 'Mess Fee', 4500.00, '2026-10-05', NULL, 'PENDING'),

(2, 'Hostel Fee', 25000.00, '2026-07-15', '2026-07-12', 'PAID'),
(2, 'Mess Fee', 4500.00, '2026-10-05', NULL, 'PENDING'),

(3, 'Hostel Fee', 25000.00, '2026-07-15', '2026-07-08', 'PAID'),
(3, 'Mess Fee', 4500.00, '2026-09-05', NULL, 'OVERDUE'),

(4, 'Hostel Fee', 24000.00, '2026-07-20', '2026-07-18', 'PAID'),
(5, 'Hostel Fee', 24000.00, '2026-07-20', NULL, 'PENDING');


-- =========================================================
-- 8. COMPLAINTS
-- =========================================================

INSERT INTO complaints
(student_id, category, title, description, priority, status, created_at, resolved_at)
VALUES
(1, 'Electrical', 'Fan not working',
 'The ceiling fan in the room is not working properly.',
 'MEDIUM', 'RESOLVED', '2026-09-10 09:30:00', '2026-09-11 15:00:00'),

(2, 'Water', 'Water supply issue',
 'Water supply is interrupted during morning hours.',
 'HIGH', 'IN_PROGRESS', '2026-09-15 08:45:00', NULL),

(3, 'Cleaning', 'Room cleaning required',
 'Room requires regular cleaning and maintenance.',
 'LOW', 'PENDING', '2026-09-20 10:15:00', NULL),

(4, 'Internet', 'WiFi connectivity issue',
 'Internet connectivity is unstable in the hostel room.',
 'MEDIUM', 'PENDING', '2026-09-25 18:20:00', NULL);


-- =========================================================
-- 9. LEAVE REQUESTS
-- =========================================================

INSERT INTO leave_requests
(student_id, from_date, to_date, reason, status, approved_by, created_at)
VALUES
(1, '2026-09-28', '2026-09-30',
 'Family function at home', 'APPROVED', 2, '2026-09-25 10:00:00'),

(2, '2026-10-10', '2026-10-12',
 'Medical appointment', 'PENDING', NULL, '2026-09-29 11:30:00'),

(3, '2026-10-05', '2026-10-06',
 'Personal work', 'APPROVED', 2, '2026-09-30 09:00:00'),

(4, '2026-10-15', '2026-10-17',
 'Visit to hometown', 'PENDING', NULL, '2026-10-01 14:00:00');


-- =========================================================
-- 10. VISITORS
-- =========================================================

INSERT INTO visitors
(student_id, visitor_name, relationship, phone, visit_date, entry_time, exit_time, status)
VALUES
(1, 'Ramesh Kumar', 'Father', '9876500011',
 '2026-09-20', '10:00:00', '12:00:00', 'COMPLETED'),

(2, 'Suresh Sharma', 'Father', '9876500012',
 '2026-09-22', '14:00:00', NULL, 'APPROVED'),

(3, 'Lakshmi Raj', 'Mother', '9876500013',
 '2026-09-25', '11:00:00', '13:00:00', 'COMPLETED'),

(4, 'Selvam', 'Father', '9876500014',
 '2026-10-01', NULL, NULL, 'PENDING');


-- =========================================================
-- 11. NOTICES
-- =========================================================

INSERT INTO notices
(title, content, created_by, created_at, expiry_date, status)
VALUES
('Hostel Maintenance Notice',
 'Electrical maintenance will be carried out this weekend.',
 2, '2026-09-20 09:00:00', '2026-10-05', 'PUBLISHED'),

('Mess Timing Update',
 'Dinner will be served from 7:00 PM to 9:00 PM.',
 2, '2026-09-25 12:00:00', '2026-10-10', 'PUBLISHED'),

('Hostel Fee Reminder',
 'Students are requested to clear pending hostel fees before the due date.',
 1, '2026-09-28 10:00:00', '2026-10-15', 'PUBLISHED'),

('Holiday Notice',
 'Hostel residents should follow the instructions issued for the upcoming holiday.',
 1, '2026-10-01 09:00:00', '2026-10-20', 'PUBLISHED');


-- =========================================================
-- COMPLETE
-- =========================================================

SELECT 'Sample data inserted successfully!' AS message;

# Hostel Management System - Frontend

React + Vite frontend for the Hostel Management System.

## Backend requirement

Start the Node/Express backend first:

```bash
cd backend
node server.js
```

Backend must run at:

`http://localhost:5000`

## Frontend setup

From this `frontend` folder:

```bash
npm install
npm run dev
```

Open the URL shown by Vite, normally:

`http://localhost:5173`

## Included

- Login screen
- Responsive sidebar
- Dashboard
- Students
- Hostels
- Rooms
- Beds
- Room Allocations
- Fees
- Complaints
- Leave Requests
- Visitors
- Notices
- Search
- Add/Edit/Delete modals
- Fee payment action
- Allocation vacate action
- Status updates
- Live dashboard counts from backend APIs

## Important

The current login screen is a frontend demo login. Any non-empty username/password is accepted. The actual database authentication API can be connected in the next backend step.

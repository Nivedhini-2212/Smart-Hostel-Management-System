import React, { useEffect, useMemo, useState } from "react";



import {

  LayoutDashboard,

  Users,

  Building2,

  DoorOpen,

  BedDouble,

  ClipboardList,

  CreditCard,

  MessageSquareWarning,

  CalendarDays,

  UserRoundCheck,

  Bell,

  LogOut,

  Menu,

  X,

  Search,

  Plus,

  Pencil,

  Trash2,

  CheckCircle2,

  AlertCircle,

  ChevronDown,

  RefreshCw,

  Home,

  ShieldCheck

} from "lucide-react";



import { api, endpoints } from "./api";



/* =====================================================

   MODULES

===================================================== */



const modules = [

  {

    key: "dashboard",

    label: "Dashboard",

    icon: LayoutDashboard,

    roles: ["ADMIN", "WARDEN", "STUDENT"]

  },



  {

    key: "students",

    label: "Students",

    icon: Users,

    roles: ["ADMIN", "WARDEN"]

  },



  {

    key: "hostels",

    label: "Hostels",

    icon: Building2,

    roles: ["ADMIN", "WARDEN"]

  },



  {

    key: "rooms",

    label: "Rooms",

    icon: DoorOpen,

    roles: ["ADMIN", "WARDEN"]

  },



  {

    key: "beds",

    label: "Beds",

    icon: BedDouble,

    roles: ["ADMIN", "WARDEN"]

  },



  {

    key: "allocations",

    label: "Allocations",

    icon: ClipboardList,

    roles: ["ADMIN", "WARDEN", "STUDENT"]

  },



  {

    key: "fees",

    label: "Fees",

    icon: CreditCard,

    roles: ["ADMIN", "WARDEN", "STUDENT"]

  },



  {

    key: "complaints",

    label: "Complaints",

    icon: MessageSquareWarning,

    roles: ["ADMIN", "WARDEN", "STUDENT"]

  },



  {

    key: "leave",

    label: "Leave Requests",

    icon: CalendarDays,

    roles: ["ADMIN", "WARDEN", "STUDENT"]

  },



  {

    key: "visitors",

    label: "Visitors",

    icon: UserRoundCheck,

    roles: ["ADMIN", "WARDEN", "STUDENT"]

  },



  {

    key: "notices",

    label: "Notices",

    icon: Bell,

    roles: ["ADMIN", "WARDEN", "STUDENT"]

  }

];



/* =====================================================

   EMPTY FORMS

===================================================== */



const emptyForms = {

  students: {

    user_id: "1",

    register_no: "",

    name: "",

    department: "Information Technology",

    year: "3",

    gender: "Female",

    phone: "",

    email: "",

    parent_name: "",

    parent_phone: "",

    address: "",

    admission_date: new Date().toISOString().slice(0, 10),

    status: "ACTIVE"

  },



  hostels: {

    hostel_name: "",

    hostel_type: "BOYS",

    location: "",

    total_rooms: "",

    status: "ACTIVE"

  },



  rooms: {

    hostel_id: "1",

    room_number: "",

    floor: "1",

    capacity: "2",

    status: "AVAILABLE"

  },



  beds: {

    room_id: "1",

    bed_number: "",

    status: "AVAILABLE"

  },



  allocations: {

    student_id: "",

    room_id: "",

    bed_id: "",

    allocation_date: new Date().toISOString().slice(0, 10),

    status: "ACTIVE"

  },



  fees: {

    student_id: "",

    fee_type: "Hostel Fee",

    amount: "",

    due_date: new Date().toISOString().slice(0, 10),

    paid_date: "",

    status: "PENDING"

  },



  complaints: {

    student_id: "",

    category: "Maintenance",

    title: "",

    description: "",

    priority: "MEDIUM",

    status: "PENDING"

  },



  leave: {

    student_id: "",

    from_date: new Date().toISOString().slice(0, 10),

    to_date: new Date().toISOString().slice(0, 10),

    reason: "",

    status: "PENDING"

  },



  visitors: {

    student_id: "",

    visitor_name: "",

    relationship: "Parent",

    phone: "",

    visit_date: new Date().toISOString().slice(0, 10),

    entry_time: "",

    exit_time: "",

    status: "PENDING"

  },



  notices: {

    title: "",

    content: "",

    created_by: "1",

    expiry_date: "",

    status: "PUBLISHED"

  }

};



/* =====================================================

   LOGIN

===================================================== */



function Login({ onLogin }) {

  const [username, setUsername] = useState("admin");

  const [password, setPassword] = useState("admin123");



  const [error, setError] = useState("");

  const [loading, setLoading] = useState(false);



  async function submit(e) {

    e.preventDefault();



    setError("");



    if (!username || !password) {

      setError("Enter username and password.");

      return;

    }



    try {

      setLoading(true);



      const result = await api.post("/auth/login", {

        username,

        password

      });



      localStorage.setItem("hms_token", result.token);



      localStorage.setItem(

        "hms_user",

        JSON.stringify(result.user)

      );



      onLogin(result.user);

    } catch (err) {

      setError(

        err.message || "Invalid username or password."

      );

    } finally {

      setLoading(false);

    }

  }



  return (

    <div className="login-shell">



      <div className="login-art">



        <div className="brand-mark">

          <Home size={30} />

        </div>



        <h1>

          Hostel Management

          <br />

          System

        </h1>



        <p>

          Manage students, rooms, allocations, fees and

          hostel operations from one place.

        </p>



        <div className="login-points">



          <span>

            <CheckCircle2 />

            Centralized management

          </span>



          <span>

            <CheckCircle2 />

            Real-time records

          </span>



          <span>

            <CheckCircle2 />

            Simple role-based workspace

          </span>



        </div>



      </div>



      <form

        className="login-card"

        onSubmit={submit}

      >



        <div className="mobile-logo">

          <Home />

        </div>



        <p className="eyebrow">

          WELCOME BACK

        </p>



        <h2>

          Sign in

        </h2>



        <p className="muted">

          Use your hostel management account.

        </p>



        {error && (

          <div className="alert error">

            <AlertCircle size={18} />

            {error}

          </div>

        )}



        <label>

          Username



          <input

            value={username}

            onChange={(e) =>

              setUsername(e.target.value)

            }

            placeholder="Enter username"

            autoComplete="username"

          />

        </label>



        <label>

          Password



          <input

            type="password"

            value={password}

            onChange={(e) =>

              setPassword(e.target.value)

            }

            placeholder="Enter password"

            autoComplete="current-password"

          />

        </label>



        <button

          className="primary full"

          type="submit"

          disabled={loading}

        >

          {loading

            ? "Signing in..."

            : "Sign In"}

        </button>



        <p className="demo-note">

          Authentication is connected to the Hostel

          Management System backend.

        </p>



      </form>



    </div>

  );

}



/* =====================================================

   APP

===================================================== */



function App() {

  const [user, setUser] = useState(() => {

    try {

      return JSON.parse(

        localStorage.getItem("hms_user") || "null"

      );

    } catch {

      return null;

    }

  });



  function logout() {

    localStorage.removeItem("hms_user");

    localStorage.removeItem("hms_token");



    setUser(null);

  }



  if (!user) {

    return <Login onLogin={setUser} />;

  }



  return (

    <Main

      user={user}

      logout={logout}

    />

  );

}



/* =====================================================

   MAIN APPLICATION

===================================================== */



function Main({ user, logout }) {

  const [active, setActive] =

    useState("dashboard");



  const [sidebar, setSidebar] =

    useState(false);



  /*

   \* Only show modules allowed for the

   \* currently logged-in user's role.

   */

  const allowedModules = useMemo(() => {

    return modules.filter(

      (module) =>

        !module.roles ||

        module.roles.includes(user.role)

    );

  }, [user.role]);



  /*

   \* If the active page is not allowed for the

   \* current role, return to dashboard.

   */

  useEffect(() => {

    const allowed = allowedModules.some(

      (module) => module.key === active

    );



    if (!allowed) {

      setActive("dashboard");

    }

  }, [allowedModules, active]);



  const current =

    allowedModules.find(

      (module) => module.key === active

    ) || allowedModules[0];



  return (

    <div className="app-shell">



      {/* SIDEBAR */}



      <aside

        className={`sidebar ${

          sidebar ? "open" : ""

        }`}

      >



        <div className="sidebar-head">



          <div className="brand-icon">

            <Home size={21} />

          </div>



          <div>

            <strong>HMS</strong>

            <small>

              Hostel Management

            </small>

          </div>



          <button

            className="icon-btn mobile-only"

            onClick={() =>

              setSidebar(false)

            }

          >

            <X />

          </button>



        </div>



        <nav>



          {allowedModules.map((module) => {

            const Icon = module.icon;



            return (

              <button

                key={module.key}

                className={

                  active === module.key

                    ? "nav active"

                    : "nav"

                }

                onClick={() => {

                  setActive(module.key);

                  setSidebar(false);

                }}

              >

                <Icon size={19} />



                <span>

                  {module.label}

                </span>

              </button>

            );

          })}



        </nav>



        <div className="sidebar-bottom">



          <div className="mini-user">



            <div className="avatar">

              {user.username

                ? user.username[0].toUpperCase()

                : "U"}

            </div>



            <div>



              <strong>

                {user.username}

              </strong>



              <small>

                {user.role}

              </small>



            </div>



          </div>



          <button

            className="logout"

            onClick={logout}

          >

            <LogOut size={17} />

            Logout

          </button>



        </div>



      </aside>



      {sidebar && (

        <div

          className="overlay"

          onClick={() =>

            setSidebar(false)

          }

        />

      )}



      {/* MAIN */}



      <main className="main">



        <header className="topbar">



          <button

            className="icon-btn mobile-only"

            onClick={() =>

              setSidebar(true)

            }

          >

            <Menu />

          </button>



          <div>



            <h2>

              {current?.label}

            </h2>



            <p>

              {active === "dashboard"

                ? "Overview of hostel operations"

                : `Manage ${

                    current?.label.toLowerCase()

                  }`}

            </p>



          </div>



          <div className="top-actions">



            <span className="role-pill">

              <ShieldCheck size={15} />

              {user.role}

            </span>



            <div className="avatar">

              {user.username

                ? user.username[0].toUpperCase()

                : "U"}

            </div>



          </div>



        </header>



        <div className="content">



          {active === "dashboard" ? (
            user.role === "STUDENT" ? (
              <StudentDashboard go={setActive} user={user} />
            ) : user.role === "WARDEN" ? (
              <WardenDashboard go={setActive} user={user} />
            ) : (
              <Dashboard go={setActive} user={user} />
            )
          ) : (

            <CrudPage

              type={active}

              user={user}

            />

          )}



        </div>



      </main>



    </div>

  );

}



/* =====================================================

   DASHBOARD

===================================================== */



function Dashboard({ go, user }) {

  const keys = Object.keys(endpoints);



  const [counts, setCounts] =

    useState({});



  const [loading, setLoading] =

    useState(true);



  const [error, setError] =

    useState("");



  const load = async () => {

    setLoading(true);

    setError("");



    try {

      const values = await Promise.all(

        keys.map((key) =>

          api.get(endpoints[key])

        )

      );



      const c = {};



      keys.forEach((key, index) => {

        c[key] =

          values[index].count ??

          values[index].data?.length ??

          0;

      });



      setCounts(c);

    } catch (e) {

      setError(e.message);

    } finally {

      setLoading(false);

    }

  };



  useEffect(() => {

    load();

  }, []);



  const allCards = [

    [

      "students",

      "Students",

      Users,

      "blue"

    ],

    [

      "hostels",

      "Hostels",

      Building2,

      "purple"

    ],

    [

      "rooms",

      "Rooms",

      DoorOpen,

      "green"

    ],

    [

      "beds",

      "Beds",

      BedDouble,

      "orange"

    ],

    [

      "allocations",

      "Allocations",

      ClipboardList,

      "cyan"

    ],

    [

      "fees",

      "Fees",

      CreditCard,

      "pink"

    ],

    [

      "complaints",

      "Complaints",

      MessageSquareWarning,

      "red"

    ],

    [

      "leave",

      "Leave Requests",

      CalendarDays,

      "indigo"

    ]

  ];



  /*

   \* Dashboard cards also respect the user's role.

   */

  const cards = allCards.filter(

    ([key]) => {

      const module = modules.find(

        (item) => item.key === key

      );



      return (

        !module?.roles ||

        module.roles.includes(user.role)

      );

    }

  );



  const quickActions = [

    {

      key: "students",

      icon: Plus,

      label: "Add student"

    },

    {

      key: "allocations",

      icon: ClipboardList,

      label: "Allocate room"

    },

    {

      key: "fees",

      icon: CreditCard,

      label: "Manage fees"

    },

    {

      key: "complaints",

      icon: MessageSquareWarning,

      label: "View complaints"

    }

  ].filter((item) => {

    const module = modules.find(

      (m) => m.key === item.key

    );



    return (

      module &&

      module.roles.includes(user.role)

    );

  });



  return (

    <div>



      <div className="welcome">



        <div>



          <p className="eyebrow">

            HOSTEL OVERVIEW

          </p>



          <h1>

            Good day! 👋

          </h1>



          <p>

            Here’s a quick view of your

            hostel management system.

          </p>



        </div>



        <button

          className="secondary"

          onClick={load}

        >

          <RefreshCw size={17} />

          Refresh

        </button>



      </div>



      {error && (

        <div className="alert error">



          <AlertCircle size={18} />



          {error}



          <span>

            Make sure the Node backend is

            running on port 5000.

          </span>



        </div>

      )}



      <div className="stat-grid">



        {cards.map(

          ([key, label, Icon, color]) => (

            <button

              className="stat-card"

              key={key}

              onClick={() => go(key)}

            >



              <div

                className={`stat-icon ${color}`}

              >

                <Icon size={21} />

              </div>



              <div>



                <span>

                  {label}

                </span>



                <strong>

                  {loading

                    ? "—"

                    : counts[key] ?? 0}

                </strong>



              </div>



            </button>

          )

        )}



      </div>



      <div className="dashboard-grid">



        <section className="panel">



          <div className="panel-head">



            <div>



              <h3>

                System status

              </h3>



              <p>

                Connected services

              </p>



            </div>



            <span className="status-dot">

              <i />

              Online

            </span>



          </div>



          <div className="status-list">



            <div>

              <span>

                Backend API

              </span>



              <b>

                localhost:5000

              </b>

            </div>



            <div>

              <span>

                Database

              </span>



              <b>

                MySQL

              </b>

            </div>



            <div>

              <span>

                Frontend

              </span>



              <b>

                React + Vite

              </b>

            </div>



            <div>

              <span>

                API modules

              </span>



              <b>

                {keys.length} connected

              </b>

            </div>



          </div>



        </section>



        <section className="panel quick">



          <div className="panel-head">



            <div>



              <h3>

                Quick actions

              </h3>



              <p>

                Jump to common tasks

              </p>



            </div>



          </div>



          <div className="quick-grid">



            {quickActions.map(

              ({

                key,

                icon: Icon,

                label

              }) => (

                <button

                  key={key}

                  onClick={() => go(key)}

                >

                  <Icon size={17} />

                  {label}

                </button>

              )

            )}



          </div>



        </section>



      </div>



    </div>

  );

}



/* =====================================================

   /* =====================================================
   WARDEN DASHBOARD
===================================================== */

function WardenDashboard({ go, user }) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [data, setData] = useState({ students: [], hostels: [], rooms: [], beds: [], allocations: [], fees: [], complaints: [], leaveRequests: [], visitors: [], notices: [] });

  const loadWardenDashboard = async () => {
    try {
      setLoading(true);
      setError("");
      const [studentsRes, hostelsRes, roomsRes, bedsRes, allocationsRes, feesRes, complaintsRes, leaveRes, visitorsRes, noticesRes] = await Promise.all([
        api.get("/students"), api.get("/hostels"), api.get("/rooms"), api.get("/beds"), api.get("/allocations"),
        api.get("/fees"), api.get("/complaints"), api.get("/leave"), api.get("/visitors"), api.get("/notices")
      ]);
      setData({
        students: studentsRes.data || [], hostels: hostelsRes.data || [], rooms: roomsRes.data || [], beds: bedsRes.data || [],
        allocations: allocationsRes.data || [], fees: feesRes.data || [], complaints: complaintsRes.data || [],
        leaveRequests: leaveRes.data || [], visitors: visitorsRes.data || [], notices: noticesRes.data || []
      });
    } catch (e) {
      setError(e.message || "Unable to load warden dashboard.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadWardenDashboard(); }, []);

  const pendingComplaints = data.complaints.filter(x => x.status === "PENDING" || x.status === "IN_PROGRESS");
  const pendingLeave = data.leaveRequests.filter(x => x.status === "PENDING");
  const pendingFees = data.fees.filter(x => x.status === "PENDING" || x.status === "OVERDUE");
  const pendingFeeAmount = pendingFees.reduce((sum, x) => sum + Number(x.amount || 0), 0);
  const occupiedBeds = data.beds.filter(x => String(x.status || "").toUpperCase() === "OCCUPIED").length;
  const availableBeds = data.beds.filter(x => String(x.status || "").toUpperCase() === "AVAILABLE").length;
  const today = new Date().toISOString().slice(0, 10);
  const todaysVisitors = data.visitors.filter(x => String(x.visit_date || "").slice(0, 10) === today);
  const recentNotices = data.notices.filter(x => x.status === "PUBLISHED").slice(0, 5);

  const cards = [
    ["students", "Students", Users, "blue", data.students.length],
    ["hostels", "Hostels", Building2, "purple", data.hostels.length],
    ["rooms", "Rooms", DoorOpen, "green", data.rooms.length],
    ["beds", "Available Beds", BedDouble, "orange", availableBeds],
    ["complaints", "Open Complaints", MessageSquareWarning, "red", pendingComplaints.length],
    ["leave", "Pending Leave", CalendarDays, "indigo", pendingLeave.length],
    ["visitors", "Today's Visitors", UserRoundCheck, "cyan", todaysVisitors.length],
    ["fees", "Pending Fees", CreditCard, "pink", pendingFees.length]
  ];

  return (
    <div>
      <div className="welcome">
        <div>
          <p className="eyebrow">WARDEN PORTAL</p>
          <h1>Good day, {user.username} 👋</h1>
          <p>Monitor students, accommodation, fees, complaints, leave and visitors.</p>
        </div>
        <button className="secondary" onClick={loadWardenDashboard}><RefreshCw size={17} /> Refresh</button>
      </div>

      {error && <div className="alert error"><AlertCircle size={18} />{error}</div>}

      <div className="stat-grid">
        {cards.map(([key, label, Icon, color, value]) => (
          <button className="stat-card" key={key} onClick={() => go(key)}>
            <div className={`stat-icon ${color}`}><Icon size={21} /></div>
            <div><span>{label}</span><strong>{loading ? "—" : value}</strong></div>
          </button>
        ))}
      </div>

      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-head"><div><h3>Accommodation Status</h3><p>Current bed availability</p></div><BedDouble size={20} /></div>
          <div className="status-list">
            <div><span>Total Beds</span><b>{loading ? "—" : data.beds.length}</b></div>
            <div><span>Occupied Beds</span><b>{loading ? "—" : occupiedBeds}</b></div>
            <div><span>Available Beds</span><b>{loading ? "—" : availableBeds}</b></div>
            <div><span>Total Rooms</span><b>{loading ? "—" : data.rooms.length}</b></div>
            <div><span>Active Allocations</span><b>{loading ? "—" : data.allocations.filter(x => x.status === "ACTIVE").length}</b></div>
          </div>
        </section>

        <section className="panel">
          <div className="panel-head"><div><h3>Attention Required</h3><p>Items waiting for action</p></div><AlertCircle size={20} /></div>
          <div className="status-list">
            <div><span>Open Complaints</span><b>{loading ? "—" : pendingComplaints.length}</b></div>
            <div><span>Pending Leave</span><b>{loading ? "—" : pendingLeave.length}</b></div>
            <div><span>Pending Fee Records</span><b>{loading ? "—" : pendingFees.length}</b></div>
            <div><span>Pending Fee Amount</span><b>{loading ? "—" : `₹${pendingFeeAmount.toLocaleString("en-IN")}`}</b></div>
          </div>
        </section>
      </div>

      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-head"><div><h3>Recent Notices</h3><p>Latest published announcements</p></div><Bell size={20} /></div>
          {recentNotices.length === 0 ? <div className="empty"><Bell /><p>No published notices.</p></div> : <div className="status-list">
            {recentNotices.map(notice => <div key={notice.notice_id}><span>{notice.title}</span><b>{formatValue(notice.created_at)}</b></div>)}
          </div>}
          <button className="secondary" style={{ marginTop: "16px" }} onClick={() => go("notices")}>Manage Notices</button>
        </section>

        <section className="panel">
          <div className="panel-head"><div><h3>Quick Actions</h3><p>Common warden activities</p></div></div>
          <div className="quick-grid">
            <button onClick={() => go("students")}><Users size={17} />Students</button>
            <button onClick={() => go("allocations")}><ClipboardList size={17} />Allocations</button>
            <button onClick={() => go("complaints")}><MessageSquareWarning size={17} />Complaints</button>
            <button onClick={() => go("leave")}><CalendarDays size={17} />Approve Leave</button>
            <button onClick={() => go("visitors")}><UserRoundCheck size={17} />Visitors</button>
            <button onClick={() => go("notices")}><Bell size={17} />Notices</button>
          </div>
        </section>
      </div>
    </div>
  );
}

/* =====================================================
   STUDENT DASHBOARD
===================================================== */

function StudentDashboard({ go, user }) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [student, setStudent] = useState(null);
  const [allocation, setAllocation] = useState(null);
  const [fees, setFees] = useState([]);
  const [complaints, setComplaints] = useState([]);
  const [leaveRequests, setLeaveRequests] = useState([]);
  const [notices, setNotices] = useState([]);

  const loadStudentDashboard = async () => {
    try {
      setLoading(true);
      setError("");

      // Students must not access the complete students,
      // hostels, rooms, or beds collections.
      // The protected profile and allocation APIs provide
      // only the information belonging to the logged-in student.
      const [
        profileRes,
        allocationsRes,
        feesRes,
        complaintsRes,
        leaveRes,
        noticesRes
      ] = await Promise.all([
        api.get("/profile"),
        api.get("/allocations"),
        api.get("/fees"),
        api.get("/complaints"),
        api.get("/leave"),
        api.get("/notices")
      ]);

      const profileList = profileRes.data || [];
      const allocations = allocationsRes.data || [];
      const allFees = feesRes.data || [];
      const allComplaints = complaintsRes.data || [];
      const allLeave = leaveRes.data || [];
      const allNotices = noticesRes.data || [];

      const myStudent = profileList[0] || null;

      if (!myStudent) {
        setStudent(null);
        setAllocation(null);
        setFees([]);
        setComplaints([]);
        setLeaveRequests([]);
        setNotices([]);
        setError("Student profile was not found for this login account.");
        return;
      }

      setStudent(myStudent);

      // The protected allocation endpoint already filters by
      // the logged-in student's user_id on the backend.
      const myAllocation = allocations.find(
        item => item.status === "ACTIVE"
      ) || null;

      setAllocation(myAllocation);

      // Keep the frontend filtering as an additional safeguard.
      setFees(
        allFees.filter(
          item => Number(item.student_id) === Number(myStudent.student_id)
        )
      );

      setComplaints(
        allComplaints.filter(
          item => Number(item.student_id) === Number(myStudent.student_id)
        )
      );

      setLeaveRequests(
        allLeave.filter(
          item => Number(item.student_id) === Number(myStudent.student_id)
        )
      );

      setNotices(
        allNotices
          .filter(item => item.status === "PUBLISHED")
          .slice(0, 5)
      );

    } catch (e) {
      setError(e.message || "Unable to load student dashboard.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStudentDashboard();
  }, [user.user_id]);

  const pendingFees = fees.filter(
    item => item.status === "PENDING" || item.status === "OVERDUE"
  );

  const pendingComplaints = complaints.filter(
    item => item.status === "PENDING" || item.status === "IN_PROGRESS"
  );

  const pendingLeave = leaveRequests.filter(
    item => item.status === "PENDING"
  );

  const totalDue = pendingFees.reduce(
    (total, item) => total + Number(item.amount || 0),
    0
  );

  return (
    <div>
      <div className="welcome">
        <div>
          <p className="eyebrow">STUDENT PORTAL</p>
          <h1>Welcome, {student?.name || user.username} 👋</h1>
          <p>
            View your hostel details, fees, complaints, leave requests and notices.
          </p>
        </div>

        <button className="secondary" onClick={loadStudentDashboard}>
          <RefreshCw size={17} />
          Refresh
        </button>
      </div>

      {error && (
        <div className="alert error">
          <AlertCircle size={18} />
          {error}
        </div>
      )}

      <div className="stat-grid">
        <button className="stat-card" onClick={() => go("allocations")}>
          <div className="stat-icon cyan">
            <BedDouble size={21} />
          </div>
          <div>
            <span>My Room</span>
            <strong>
              {loading
                ? "—"
                : allocation?.room_number || "Not Allocated"}
            </strong>
          </div>
        </button>

        <button className="stat-card" onClick={() => go("fees")}>
          <div className="stat-icon pink">
            <CreditCard size={21} />
          </div>
          <div>
            <span>Fee Due</span>
            <strong>
              {loading
                ? "—"
                : `₹${totalDue.toLocaleString("en-IN")}`}
            </strong>
          </div>
        </button>

        <button className="stat-card" onClick={() => go("complaints")}>
          <div className="stat-icon red">
            <MessageSquareWarning size={21} />
          </div>
          <div>
            <span>Complaints</span>
            <strong>
              {loading ? "—" : pendingComplaints.length}
            </strong>
          </div>
        </button>

        <button className="stat-card" onClick={() => go("leave")}>
          <div className="stat-icon indigo">
            <CalendarDays size={21} />
          </div>
          <div>
            <span>Leave Requests</span>
            <strong>
              {loading ? "—" : pendingLeave.length}
            </strong>
          </div>
        </button>
      </div>

      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-head">
            <div>
              <h3>My Allocation</h3>
              <p>Current hostel accommodation</p>
            </div>
            <BedDouble size={20} />
          </div>

          {loading ? (
            <div className="empty">
              <RefreshCw className="spin" />
              <p>Loading allocation...</p>
            </div>
          ) : allocation ? (
            <div className="status-list">
              <div>
                <span>Hostel</span>
                <b>{allocation.hostel_name || "—"}</b>
              </div>

              <div>
                <span>Room</span>
                <b>{allocation.room_number || "—"}</b>
              </div>

              <div>
                <span>Bed</span>
                <b>{allocation.bed_number || "—"}</b>
              </div>

              <div>
                <span>Allocation Date</span>
                <b>{formatValue(allocation.allocation_date)}</b>
              </div>

              <div>
                <span>Status</span>
                <b>{allocation.status || "—"}</b>
              </div>
            </div>
          ) : (
            <div className="empty">
              <BedDouble />
              <h3>No allocation</h3>
              <p>
                You currently do not have an active room allocation.
              </p>
            </div>
          )}
        </section>

        <section className="panel">
          <div className="panel-head">
            <div>
              <h3>My Profile</h3>
              <p>Student information</p>
            </div>
            <Users size={20} />
          </div>

          {loading ? (
            <div className="empty">
              <RefreshCw className="spin" />
              <p>Loading profile...</p>
            </div>
          ) : (
            <div className="status-list">
              <div>
                <span>Name</span>
                <b>{student?.name || "—"}</b>
              </div>

              <div>
                <span>Register No</span>
                <b>{student?.register_no || "—"}</b>
              </div>

              <div>
                <span>Department</span>
                <b>{student?.department || "—"}</b>
              </div>

              <div>
                <span>Year</span>
                <b>{student?.year || "—"}</b>
              </div>

              <div>
                <span>Email</span>
                <b>{student?.email || "—"}</b>
              </div>
            </div>
          )}
        </section>
      </div>

      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-head">
            <div>
              <h3>Fee Status</h3>
              <p>Your recent fee records</p>
            </div>
            <CreditCard size={20} />
          </div>

          {fees.length === 0 ? (
            <div className="empty">
              <CreditCard />
              <p>No fee records found.</p>
            </div>
          ) : (
            <div className="status-list">
              {fees.slice(0, 4).map(fee => (
                <div key={fee.fee_id}>
                  <span>{fee.fee_type}</span>
                  <b>
                    ₹{Number(fee.amount || 0).toLocaleString("en-IN")} · {fee.status}
                  </b>
                </div>
              ))}
            </div>
          )}

          <button
            className="secondary"
            style={{ marginTop: "16px" }}
            onClick={() => go("fees")}
          >
            View My Fees
          </button>
        </section>

        <section className="panel">
          <div className="panel-head">
            <div>
              <h3>Recent Notices</h3>
              <p>Latest hostel announcements</p>
            </div>
            <Bell size={20} />
          </div>

          {notices.length === 0 ? (
            <div className="empty">
              <Bell />
              <p>No notices available.</p>
            </div>
          ) : (
            <div className="status-list">
              {notices.map(notice => (
                <div key={notice.notice_id}>
                  <span>{notice.title}</span>
                  <b>{formatValue(notice.created_at)}</b>
                </div>
              ))}
            </div>
          )}

          <button
            className="secondary"
            style={{ marginTop: "16px" }}
            onClick={() => go("notices")}
          >
            View Notices
          </button>
        </section>
      </div>

      <section className="panel" style={{ marginTop: "20px" }}>
        <div className="panel-head">
          <div>
            <h3>Quick Actions</h3>
            <p>Common student activities</p>
          </div>
        </div>

        <div className="quick-grid">
          <button onClick={() => go("complaints")}>
            <MessageSquareWarning size={17} />
            My Complaints
          </button>

          <button onClick={() => go("leave")}>
            <CalendarDays size={17} />
            Apply Leave
          </button>

          <button onClick={() => go("visitors")}>
            <UserRoundCheck size={17} />
            Manage Visitors
          </button>

          <button onClick={() => go("notices")}>
            <Bell size={17} />
            View Notices
          </button>
        </div>
      </section>
    </div>
  );
}

/* =====================================================
   CRUD CONFIGURATION
===================================================== */



const configs = {

  students: {

    title: "Students",

    singular: "Student",



    fields: [

      ["user_id", "User ID", "number"],

      [

        "register_no",

        "Register No",

        "text"

      ],

      [

        "name",

        "Full Name",

        "text"

      ],

      [

        "department",

        "Department",

        "text"

      ],

      [

        "year",

        "Year",

        "number"

      ],

      [

        "gender",

        "Gender",

        "select:Male|Female|Other"

      ],

      [

        "phone",

        "Phone",

        "text"

      ],

      [

        "email",

        "Email",

        "email"

      ],

      [

        "parent_name",

        "Parent Name",

        "text"

      ],

      [

        "parent_phone",

        "Parent Phone",

        "text"

      ],

      [

        "address",

        "Address",

        "textarea"

      ],

      [

        "admission_date",

        "Admission Date",

        "date"

      ],

      [

        "status",

        "Status",

        "select:ACTIVE|INACTIVE"

      ]

    ]

  },



  hostels: {

    title: "Hostels",

    singular: "Hostel",



    fields: [

      [

        "hostel_name",

        "Hostel Name",

        "text"

      ],

      [

        "hostel_type",

        "Type",

        "select:BOYS|GIRLS"

      ],

      [

        "location",

        "Location",

        "text"

      ],

      [

        "total_rooms",

        "Total Rooms",

        "number"

      ],

      [

        "status",

        "Status",

        "select:ACTIVE|INACTIVE"

      ]

    ]

  },



  rooms: {

    title: "Rooms",

    singular: "Room",



    fields: [

      [

        "hostel_id",

        "Hostel ID",

        "number"

      ],

      [

        "room_number",

        "Room Number",

        "text"

      ],

      [

        "floor",

        "Floor",

        "number"

      ],

      [

        "capacity",

        "Capacity",

        "number"

      ],

      [

        "status",

        "Status",

        "select:AVAILABLE|FULL|MAINTENANCE|INACTIVE"

      ]

    ]

  },



  beds: {

    title: "Beds",

    singular: "Bed",



    fields: [

      [

        "room_id",

        "Room ID",

        "number"

      ],

      [

        "bed_number",

        "Bed Number",

        "text"

      ],

      [

        "status",

        "Status",

        "select:AVAILABLE|OCCUPIED|MAINTENANCE"

      ]

    ]

  },



  allocations: {

    title: "Room Allocations",

    singular: "Allocation",



    fields: [

      [

        "student_id",

        "Student ID",

        "number"

      ],

      [

        "room_id",

        "Room ID",

        "number"

      ],

      [

        "bed_id",

        "Bed ID",

        "number"

      ],

      [

        "allocation_date",

        "Allocation Date",

        "date"

      ],

      [

        "status",

        "Status",

        "select:ACTIVE|VACATED|CANCELLED"

      ]

    ]

  },



  fees: {

    title: "Fees",

    singular: "Fee",



    fields: [

      [

        "student_id",

        "Student ID",

        "number"

      ],

      [

        "fee_type",

        "Fee Type",

        "text"

      ],

      [

        "amount",

        "Amount",

        "number"

      ],

      [

        "due_date",

        "Due Date",

        "date"

      ],

      [

        "paid_date",

        "Paid Date",

        "date"

      ],

      [

        "status",

        "Status",

        "select:PENDING|PAID|OVERDUE|CANCELLED"

      ]

    ]

  },



  complaints: {

    title: "Complaints",

    singular: "Complaint",



    fields: [

      [

        "student_id",

        "Student ID",

        "number"

      ],

      [

        "category",

        "Category",

        "text"

      ],

      [

        "title",

        "Title",

        "text"

      ],

      [

        "description",

        "Description",

        "textarea"

      ],

      [

        "priority",

        "Priority",

        "select:LOW|MEDIUM|HIGH"

      ],

      [

        "status",

        "Status",

        "select:PENDING|IN_PROGRESS|RESOLVED|CLOSED"

      ]

    ]

  },



  leave: {

    title: "Leave Requests",

    singular: "Leave Request",



    fields: [

      [

        "student_id",

        "Student ID",

        "number"

      ],

      [

        "from_date",

        "From Date",

        "date"

      ],

      [

        "to_date",

        "To Date",

        "date"

      ],

      [

        "reason",

        "Reason",

        "textarea"

      ],

      [

        "status",

        "Status",

        "select:PENDING|APPROVED|REJECTED|CANCELLED"

      ]

    ]

  },



  visitors: {

    title: "Visitors",

    singular: "Visitor",



    fields: [

      [

        "student_id",

        "Student ID",

        "number"

      ],

      [

        "visitor_name",

        "Visitor Name",

        "text"

      ],

      [

        "relationship",

        "Relationship",

        "text"

      ],

      [

        "phone",

        "Phone",

        "text"

      ],

      [

        "visit_date",

        "Visit Date",

        "date"

      ],

      [

        "entry_time",

        "Entry Time",

        "time"

      ],

      [

        "exit_time",

        "Exit Time",

        "time"

      ],

      [

        "status",

        "Status",

        "select:PENDING|APPROVED|REJECTED|COMPLETED"

      ]

    ]

  },



  notices: {

    title: "Notices",

    singular: "Notice",



    fields: [

      [

        "title",

        "Title",

        "text"

      ],

      [

        "content",

        "Content",

        "textarea"

      ],

      [

        "created_by",

        "Created By User ID",

        "number"

      ],

      [

        "expiry_date",

        "Expiry Date",

        "date"

      ],

      [

        "status",

        "Status",

        "select:DRAFT|PUBLISHED|EXPIRED"

      ]

    ]

  }

};



/* =====================================================

   CRUD PAGE

===================================================== */



function CrudPage({ type, user }) {

  const cfg = configs[type];



  const [rows, setRows] =

    useState([]);



  const [loading, setLoading] =

    useState(true);



  const [search, setSearch] =

    useState("");



  const [modal, setModal] =

    useState(null);



  const [form, setForm] =

    useState({

      ...emptyForms[type]

    });



  const [error, setError] =

    useState("");



  const load = async () => {

    setLoading(true);

    setError("");



    try {

      const data = await api.get(

        endpoints[type]

      );



      setRows(data.data || []);

    } catch (e) {

      setError(e.message);

    } finally {

      setLoading(false);

    }

  };



  useEffect(() => {

    load();

  }, [type]);



  const filtered = useMemo(() => {

    return rows.filter((row) =>

      JSON.stringify(row)

        .toLowerCase()

        .includes(

          search.toLowerCase()

        )

    );

  }, [rows, search]);



  const primaryId = {

    students: "student_id",

    hostels: "hostel_id",

    rooms: "room_id",

    beds: "bed_id",

    allocations: "allocation_id",

    fees: "fee_id",

    complaints: "complaint_id",

    leave: "leave_id",

    visitors: "visitor_id",

    notices: "notice_id"

  }[type];



  function openNew() {

    setForm({

      ...emptyForms[type]

    });



    setModal("new");

    setError("");

  }



  function openEdit(row) {

    const f = {

      ...emptyForms[type]

    };



    cfg.fields.forEach(([key]) => {

      f[key] = row[key] ?? "";

    });



    setForm(f);



    setModal(row[primaryId]);



    setError("");

  }



  async function save(e) {

    e.preventDefault();



    setError("");



    try {

      if (modal === "new") {

        await api.post(

          endpoints[type],

          normalize(form)

        );

      } else {

        await api.put(

          `${endpoints[type]}/${modal}`,

          normalize(form)

        );

      }



      setModal(null);



      await load();

    } catch (e) {

      setError(e.message);

    }

  }



  async function remove(id) {

    if (

      !confirm(

        `Delete this ${cfg.singular.toLowerCase()}?`

      )

    ) {

      return;

    }



    try {

      await api.del(

        `${endpoints[type]}/${id}`

      );



      await load();

    } catch (e) {

      setError(e.message);

    }

  }



  async function special(row, action) {

    try {

      if (action === "pay") {

        await api.put(

          `/fees/${row.fee_id}/pay`,

          {}

        );

      }



      if (action === "vacate") {

        await api.put(

          `/allocations/${row.allocation_id}/vacate`,

          {}

        );

      }



      if (action === "status") {

        const value = prompt(

          "Enter new status:",

          row.status

        );



        if (value) {

          await api.put(

            `${endpoints[type]}/${row[primaryId]}/status`,

            {

              status: value.toUpperCase()

            }

          );

        }

      }



      await load();

    } catch (e) {

      setError(e.message);

    }

  }



  return (

    <div>



      <div className="page-head">



        <div>



          <h1>

            {cfg.title}

          </h1>



          <p>

            {rows.length} records

          </p>



        </div>



        <button

          className="primary"

          onClick={openNew}

        >

          <Plus size={18} />

          Add {cfg.singular}

        </button>



      </div>



      {error && (

        <div className="alert error">

          <AlertCircle size={18} />

          {error}

        </div>

      )}



      <div className="toolbar">



        <div className="search">



          <Search size={18} />



          <input

            placeholder={`Search ${cfg.title.toLowerCase()}...`}

            value={search}

            onChange={(e) =>

              setSearch(e.target.value)

            }

          />



        </div>



        <button

          className="secondary"

          onClick={load}

        >

          <RefreshCw size={17} />

          Refresh

        </button>



      </div>



      <div className="table-panel">



        <div className="table-wrap">



          {loading ? (

            <div className="empty">



              <RefreshCw className="spin" />



              <p>

                Loading...

              </p>



            </div>

          ) : filtered.length === 0 ? (

            <div className="empty">



              <Search />



              <h3>

                No records found

              </h3>



              <p>

                Try another search or add

                a new record.

              </p>



            </div>

          ) : (

            <table>



              <thead>



                <tr>



                  {cfg.fields

                    .slice(0, 5)

                    .map(([key, label]) => (

                      <th key={key}>

                        {label}

                      </th>

                    ))}



                  <th>

                    Actions

                  </th>



                </tr>



              </thead>



              <tbody>



                {filtered.map((row, index) => (

                  <tr

                    key={

                      row[primaryId] ??

                      index

                    }

                  >



                    {cfg.fields

                      .slice(0, 5)

                      .map(([key]) => (

                        <td key={key}>

                          {formatValue(

                            row[key]

                          )}

                        </td>

                      ))}



                    <td>



                      <div className="row-actions">



                        <button

                          className="icon-btn edit"

                          title="Edit"

                          onClick={() =>

                            openEdit(row)

                          }

                        >

                          <Pencil size={16} />

                        </button>



                        {type === "fees" &&

                          row.status !== "PAID" && (

                            <button

                              className="icon-btn success"

                              title="Mark paid"

                              onClick={() =>

                                special(

                                  row,

                                  "pay"

                                )

                              }

                            >

                              <CheckCircle2

                                size={16}

                              />

                            </button>

                          )}



                        {type === "allocations" &&

                          row.status === "ACTIVE" && (

                            <button

                              className="icon-btn success"

                              title="Vacate"

                              onClick={() =>

                                special(

                                  row,

                                  "vacate"

                                )

                              }

                            >

                              <DoorOpen

                                size={16}

                              />

                            </button>

                          )}



                        {[

                          "complaints",

                          "leave",

                          "visitors",

                          "notices"

                        ].includes(type) && (

                          <button

                            className="icon-btn"

                            title="Change status"

                            onClick={() =>

                              special(

                                row,

                                "status"

                              )

                            }

                          >

                            <ChevronDown

                              size={16}

                            />

                          </button>

                        )}



                        <button

                          className="icon-btn danger"

                          title="Delete"

                          onClick={() =>

                            remove(

                              row[primaryId]

                            )

                          }

                        >

                          <Trash2 size={16} />

                        </button>



                      </div>



                    </td>



                  </tr>

                ))}



              </tbody>



            </table>

          )}



        </div>



      </div>



      {modal && (

        <Modal

          title={`${

            modal === "new"

              ? "Add"

              : "Edit"

          } ${cfg.singular}`}

          onClose={() =>

            setModal(null)

          }

        >



          <form onSubmit={save}>



            <div className="form-grid">



              {cfg.fields.map(

                ([key, label, fieldType]) => (

                  <Field

                    key={key}

                    name={key}

                    label={label}

                    type={fieldType}

                    value={

                      form[key] ?? ""

                    }

                    onChange={(value) =>

                      setForm({

                        ...form,

                        [key]: value

                      })

                    }

                  />

                )

              )}



            </div>



            {error && (

              <div className="alert error">

                {error}

              </div>

            )}



            <div className="modal-actions">



              <button

                type="button"

                className="secondary"

                onClick={() =>

                  setModal(null)

                }

              >

                Cancel

              </button>



              <button

                className="primary"

                type="submit"

              >

                Save {cfg.singular}

              </button>



            </div>



          </form>



        </Modal>

      )}



    </div>

  );

}



/* =====================================================

   FIELD

===================================================== */



function Field({

  name,

  label,

  type,

  value,

  onChange

}) {

  if (type === "textarea") {

    return (

      <label className="field full-field">



        {label}



        <textarea

          value={value}

          onChange={(e) =>

            onChange(e.target.value)

          }

          required={

            name !== "address"

          }

        />



      </label>

    );

  }



  if (type.startsWith("select:")) {

    return (

      <label className="field">



        {label}



        <select

          value={value}

          onChange={(e) =>

            onChange(e.target.value)

          }

        >



          {type

            .slice(7)

            .split("|")

            .map((option) => (

              <option

                key={option}

                value={option}

              >

                {option.replaceAll(

                  "_",

                  " "

                )}

              </option>

            ))}



        </select>



      </label>

    );

  }



  return (

    <label className="field">



      {label}



      <input

        type={type}

        value={value}

        onChange={(e) =>

          onChange(e.target.value)

        }

        required={

          ![

            "email",

            "expiry_date",

            "paid_date",

            "entry_time",

            "exit_time"

          ].includes(name)

        }

      />



    </label>

  );

}



/* =====================================================

   NORMALIZE DATA

===================================================== */



function normalize(obj) {

  const output = {

    ...obj

  };



  for (const key of Object.keys(output)) {



    if (output[key] === "") {

      output[key] = null;

    }



    else if (

      [

        "user_id",

        "year",

        "hostel_id",

        "total_rooms",

        "room_id",

        "capacity",

        "bed_id",

        "student_id",

        "created_by",

        "floor"

      ].includes(key) &&

      output[key] != null

    ) {

      output[key] = Number(

        output[key]

      );

    }



    else if (

      key === "amount" &&

      output[key] != null

    ) {

      output[key] = Number(

        output[key]

      );

    }

  }



  return output;

}



/* =====================================================

   FORMAT VALUE

===================================================== */



function formatValue(value) {

  if (

    value === null ||

    value === undefined ||

    value === ""

  ) {

    return "—";

  }



  if (

    typeof value === "string" &&

    value.includes("T") &&

    value.length > 15

  ) {

    return value.slice(0, 10);

  }



  return String(value);

}



/* =====================================================

   MODAL

===================================================== */



function Modal({

  title,

  onClose,

  children

}) {

  return (

    <div className="modal-backdrop">



      <div className="modal">



        <div className="modal-head">



          <div>



            <h2>

              {title}

            </h2>



            <p>

              Enter the details below.

            </p>



          </div>



          <button

            className="icon-btn"

            onClick={onClose}

            type="button"

          >

            <X />

          </button>



        </div>



        {children}



      </div>



    </div>

  );

}



export default App;
const API_BASE = "http://localhost:5000/api";

const collectionKeys = {
    students: ["students", "data"],
    hostels: ["hostels", "data"],
    rooms: ["rooms", "data"],
    beds: ["beds", "data"],
    allocations: ["allocations", "data"],
    fees: ["fees", "data"],
    complaints: ["complaints", "data"],
    leave: [
        "leave_requests",
        "leave",
        "leaveRequests",
        "leaves",
        "data"
    ],
    visitors: ["visitors", "data"],
    notices: ["notices", "data"],
};

function normalizeResponse(path, result) {
    if (!result || typeof result !== "object") {
        return result;
    }

    const key = path.split("/").filter(Boolean)[0];

    const candidates = collectionKeys[key] || ["data"];

    let list = null;

    for (const candidate of candidates) {
        if (Array.isArray(result[candidate])) {
            list = result[candidate];
            break;
        }
    }

    if (list) {
        return {
            ...result,
            data: list,
            count: result.count ?? list.length
        };
    }

    return result;
}

async function request(path, options = {}) {

    // Get JWT token saved during login
    const token = localStorage.getItem("hms_token");

    const response = await fetch(`${API_BASE}${path}`, {
        ...options,

        headers: {
            "Content-Type": "application/json",

            // Send JWT token to protected backend APIs
            ...(token
                ? {
                    Authorization: `Bearer ${token}`
                }
                : {}),

            ...(options.headers || {})
        }
    });

    const result = await response.json().catch(() => ({}));

    if (!response.ok || result.success === false) {

        throw new Error(
            result.message ||
            `Request failed (${response.status})`
        );
    }

    return normalizeResponse(path, result);
}

export const api = {

    get: (path) => {
        return request(path);
    },

    post: (path, body) => {
        return request(path, {
            method: "POST",
            body: JSON.stringify(body)
        });
    },

    put: (path, body) => {
        return request(path, {
            method: "PUT",
            body: JSON.stringify(body)
        });
    },

    del: (path) => {
        return request(path, {
            method: "DELETE"
        });
    }

};

export const endpoints = {

    students: "/students",

    hostels: "/hostels",

    rooms: "/rooms",

    beds: "/beds",

    allocations: "/allocations",

    fees: "/fees",

    complaints: "/complaints",

    leave: "/leave",

    visitors: "/visitors",

    notices: "/notices"

};
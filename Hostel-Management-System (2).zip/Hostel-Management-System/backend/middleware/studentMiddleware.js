const db = require("../config/db");

function attachStudentId(req, res, next) {

    // Only students need student-specific filtering
    if (req.user.role !== "STUDENT") {
        return next();
    }

    const userId = req.user.user_id;

    const sql = `
        SELECT student_id
        FROM students
        WHERE user_id = ?
        LIMIT 1
    `;

    db.query(sql, [userId], (err, results) => {

        if (err) {
            console.error("Student lookup error:", err);

            return res.status(500).json({
                success: false,
                message: "Unable to identify student"
            });
        }

        if (results.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Student profile not found"
            });
        }

        // Attach the real student_id obtained from database
        req.studentId = results[0].student_id;

        next();
    });
}

module.exports = {
    attachStudentId
};
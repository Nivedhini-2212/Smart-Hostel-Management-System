const express = require("express");
const cors = require("cors");

const db = require("./config/db");

// ===============================
// ROUTES
// ===============================

const studentRoutes = require("./routes/studentRoutes");
const hostelRoutes = require("./routes/hostelRoutes");
const roomRoutes = require("./routes/roomRoutes");
const bedRoutes = require("./routes/bedRoutes");
const allocationRoutes = require("./routes/allocationRoutes");
const feeRoutes = require("./routes/feeRoutes");
const complaintRoutes = require("./routes/complaintRoutes");
const leaveRoutes = require("./routes/leaveRoutes");
const visitorRoutes = require("./routes/visitorRoutes");
const noticeRoutes = require("./routes/noticeRoutes");
const authRoutes = require("./routes/authRoutes");
const profileRoutes = require("./routes/profileRoutes");

// ===============================
// JWT MIDDLEWARE
// ===============================

const {
    authenticateToken,
    authorizeRoles
} = require("./middleware/authMiddleware");

const {
    attachStudentId
} = require("./middleware/studentMiddleware");

// ===============================
// CREATE EXPRESS APP
// ===============================

const app = express();

// ===============================
// GENERAL MIDDLEWARE
// ===============================

app.use(cors());
app.use(express.json());

// ===============================
// AUTHENTICATION ROUTE
// ===============================

// Login does NOT require JWT
app.use("/api/auth", authRoutes);

app.use(
    "/api/profile",
    authenticateToken,
    authorizeRoles("STUDENT"),
    profileRoutes
);

// ===============================
// PROTECTED ADMIN / WARDEN ROUTES
// ===============================

// Students
app.use(
    "/api/students",
    authenticateToken,
    authorizeRoles("ADMIN", "WARDEN"),
    studentRoutes
);

// Hostels
app.use(
    "/api/hostels",
    authenticateToken,
    authorizeRoles("ADMIN", "WARDEN"),
    hostelRoutes
);

// Rooms
app.use(
    "/api/rooms",
    authenticateToken,
    authorizeRoles("ADMIN", "WARDEN"),
    roomRoutes
);

// Beds
app.use(
    "/api/beds",
    authenticateToken,
    authorizeRoles("ADMIN", "WARDEN"),
    bedRoutes
);

// ===============================
// STUDENT-ACCESSIBLE ROUTES
// ===============================

// Allocations
app.use(
    "/api/allocations",
    authenticateToken,
    authorizeRoles("ADMIN", "WARDEN", "STUDENT"),
    attachStudentId,
    allocationRoutes
);

// Fees
app.use(
    "/api/fees",
    authenticateToken,
    authorizeRoles("ADMIN", "WARDEN", "STUDENT"),
    attachStudentId,
    feeRoutes
);

// Complaints
app.use(
    "/api/complaints",
    authenticateToken,
    authorizeRoles("ADMIN", "WARDEN", "STUDENT"),
    attachStudentId,
    complaintRoutes
);

// Leave Requests
app.use(
    "/api/leave",
    authenticateToken,
    authorizeRoles("ADMIN", "WARDEN", "STUDENT"),
    attachStudentId,
    leaveRoutes
);

// Visitors
app.use(
    "/api/visitors",
    authenticateToken,
    authorizeRoles("ADMIN", "WARDEN", "STUDENT"),
    attachStudentId,
    visitorRoutes
);

// Notices
// Notices are common to all authenticated users,
// so attachStudentId is not required here.
app.use(
    "/api/notices",
    authenticateToken,
    authorizeRoles("ADMIN", "WARDEN", "STUDENT"),
    noticeRoutes
);

// ===============================
// HOME ROUTE
// ===============================

app.get("/", (req, res) => {

    res.json({
        success: true,
        message: "Hostel Management System Backend is running!"
    });

});

// ===============================
// DATABASE TEST ROUTE
// ===============================

app.get("/api/test-db", (req, res) => {

    db.query("SELECT 1 AS result", (err, results) => {

        if (err) {

            console.error("Database query failed:", err);

            return res.status(500).json({
                success: false,
                message: "Database connection failed"
            });
        }

        res.json({
            success: true,
            message: "Database connection successful!",
            result: results
        });

    });

});

// ===============================
// START SERVER
// ===============================

const PORT = 5000;

app.listen(PORT, () => {

    console.log(
        `🚀 Server running on http://localhost:${PORT}`
    );

});
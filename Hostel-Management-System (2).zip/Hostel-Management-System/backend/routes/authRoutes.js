const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../config/db");

const router = express.Router();

// Use Promise version of the existing MySQL pool
const promiseDb = db.promise();

const JWT_SECRET =
    process.env.JWT_SECRET || "hostel-management-secret-key";


// =====================================================
// LOGIN
// =====================================================

router.post("/login", async (req, res) => {

    try {

        const { username, password } = req.body;

        // ---------------------------------------------
        // Validate input
        // ---------------------------------------------

        if (!username || !password) {

            return res.status(400).json({
                success: false,
                message: "Username and password are required"
            });

        }


        // ---------------------------------------------
        // Find user
        // ---------------------------------------------

        const [users] = await promiseDb.query(
            `SELECT
                user_id,
                username,
                password,
                role,
                created_at
             FROM users
             WHERE username = ?`,
            [username]
        );


        // ---------------------------------------------
        // User not found
        // ---------------------------------------------

        if (users.length === 0) {

            return res.status(401).json({
                success: false,
                message: "Invalid username or password"
            });

        }


        const user = users[0];


        // ---------------------------------------------
        // Check password
        // ---------------------------------------------

        let passwordValid = false;


        // If password is BCrypt encrypted
        if (
            user.password &&
            user.password.startsWith("$2")
        ) {

            passwordValid = await bcrypt.compare(
                password,
                user.password
            );

        }

        // If existing database password is plain text
        else {

            passwordValid = password === user.password;

        }


        // ---------------------------------------------
        // Invalid password
        // ---------------------------------------------

        if (!passwordValid) {

            return res.status(401).json({
                success: false,
                message: "Invalid username or password"
            });

        }


        // ---------------------------------------------
        // Generate JWT token
        // ---------------------------------------------

        const token = jwt.sign(
            {
                user_id: user.user_id,
                username: user.username,
                role: user.role
            },
            JWT_SECRET,
            {
                expiresIn: "8h"
            }
        );


        // ---------------------------------------------
        // Successful login
        // ---------------------------------------------

        return res.status(200).json({

            success: true,

            message: "Login successful",

            token: token,

            user: {
                user_id: user.user_id,
                username: user.username,
                role: user.role
            }

        });

    }

    catch (error) {

        console.error("Login error:", error);

        return res.status(500).json({
            success: false,
            message: "Server error during login"
        });

    }

});


// =====================================================
// AUTHENTICATION TEST ROUTE
// =====================================================

router.get("/test", (req, res) => {

    res.json({
        success: true,
        message: "Authentication route is working!"
    });

});


// =====================================================
// EXPORT ROUTER
// =====================================================

module.exports = router;
const express = require('express');
const router = express.Router();

const db = require('../config/db');

// =====================================
// GET ALL COMPLAINTS
// ADMIN / WARDEN -> ALL COMPLAINTS
// STUDENT -> ONLY OWN COMPLAINTS
// =====================================

router.get('/', (req, res) => {

    let sql = `
        SELECT
            c.complaint_id,
            c.student_id,
            s.register_no,
            s.name AS student_name,
            c.category,
            c.title,
            c.description,
            c.priority,
            c.status,
            c.created_at,
            c.resolved_at
        FROM complaints c
        JOIN students s
            ON c.student_id = s.student_id
    `;

    const params = [];

    // Student can see only their own complaints
    if (req.user.role === 'STUDENT') {
        sql += `
            WHERE s.user_id = ?
        `;

        params.push(req.user.user_id);
    }

    sql += `
        ORDER BY c.created_at DESC
    `;

    db.query(sql, params, (err, results) => {

        if (err) {
            console.error('Error fetching complaints:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch complaints'
            });
        }

        res.json({
            success: true,
            complaints: results
        });
    });
});


// =====================================
// GET COMPLAINT BY ID
// ADMIN / WARDEN -> ANY COMPLAINT
// STUDENT -> ONLY OWN COMPLAINT
// =====================================

router.get('/:id', (req, res) => {

    const complaintId = req.params.id;

    let sql = `
        SELECT
            c.complaint_id,
            c.student_id,
            s.register_no,
            s.name AS student_name,
            c.category,
            c.title,
            c.description,
            c.priority,
            c.status,
            c.created_at,
            c.resolved_at
        FROM complaints c
        JOIN students s
            ON c.student_id = s.student_id
        WHERE c.complaint_id = ?
    `;

    const params = [complaintId];

    // Student can access only their own complaint
    if (req.user.role === 'STUDENT') {
        sql += `
            AND s.user_id = ?
        `;

        params.push(req.user.user_id);
    }

    db.query(sql, params, (err, results) => {

        if (err) {
            console.error('Error fetching complaint:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch complaint'
            });
        }

        if (results.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Complaint not found'
            });
        }

        res.json({
            success: true,
            complaint: results[0]
        });
    });
});


// =====================================
// ADD NEW COMPLAINT
// ADMIN / WARDEN -> CAN ADD
// STUDENT -> CAN ADD ONLY FOR THEMSELVES
// =====================================

router.post('/', (req, res) => {

    const {
        student_id,
        category,
        title,
        description,
        priority,
        status
    } = req.body;

    if (
        !category ||
        !title ||
        !description
    ) {
        return res.status(400).json({
            success: false,
            message: 'Please provide category, title and description'
        });
    }

    // =====================================
    // STUDENT
    // Derive student_id from logged-in user
    // Do NOT trust student_id sent by frontend
    // =====================================

    if (req.user.role === 'STUDENT') {

        const findStudentSql = `
            SELECT student_id
            FROM students
            WHERE user_id = ?
            LIMIT 1
        `;

        db.query(
            findStudentSql,
            [req.user.user_id],
            (studentErr, studentResults) => {

                if (studentErr) {
                    console.error(
                        'Error finding student:',
                        studentErr
                    );

                    return res.status(500).json({
                        success: false,
                        message: 'Failed to identify student'
                    });
                }

                if (studentResults.length === 0) {
                    return res.status(404).json({
                        success: false,
                        message: 'Student profile not found'
                    });
                }

                const ownStudentId =
                    studentResults[0].student_id;

                const insertSql = `
                    INSERT INTO complaints
                    (
                        student_id,
                        category,
                        title,
                        description,
                        priority,
                        status
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                `;

                const values = [
                    ownStudentId,
                    category,
                    title,
                    description,
                    priority || 'MEDIUM',
                    'PENDING'
                ];

                db.query(
                    insertSql,
                    values,
                    (err, result) => {

                        if (err) {
                            console.error(
                                'Error adding complaint:',
                                err
                            );

                            return res.status(500).json({
                                success: false,
                                message: 'Failed to add complaint',
                                error: err.message
                            });
                        }

                        res.status(201).json({
                            success: true,
                            message:
                                'Complaint submitted successfully!',
                            complaint_id: result.insertId
                        });
                    }
                );
            }
        );

        return;
    }


    // =====================================
    // ADMIN / WARDEN
    // Can create complaint for any student
    // =====================================

    if (!student_id) {
        return res.status(400).json({
            success: false,
            message: 'Please provide student_id'
        });
    }

    const sql = `
        INSERT INTO complaints
        (
            student_id,
            category,
            title,
            description,
            priority,
            status
        )
        VALUES (?, ?, ?, ?, ?, ?)
    `;

    const values = [
        student_id,
        category,
        title,
        description,
        priority || 'MEDIUM',
        status || 'PENDING'
    ];

    db.query(sql, values, (err, result) => {

        if (err) {
            console.error('Error adding complaint:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to add complaint',
                error: err.message
            });
        }

        res.status(201).json({
            success: true,
            message: 'Complaint submitted successfully!',
            complaint_id: result.insertId
        });
    });
});


// =====================================
// UPDATE COMPLAINT
// ADMIN / WARDEN -> CAN UPDATE ANY
// STUDENT -> CAN UPDATE ONLY OWN
// STUDENT CANNOT CHANGE STATUS
// =====================================

router.put('/:id', (req, res) => {

    const complaintId = req.params.id;

    const {
        category,
        title,
        description,
        priority,
        status
    } = req.body;

    if (
        !category ||
        !title ||
        !description
    ) {
        return res.status(400).json({
            success: false,
            message: 'Please provide category, title and description'
        });
    }

    // =====================================
    // STUDENT
    // Only own complaint
    // Status cannot be changed
    // =====================================

    if (req.user.role === 'STUDENT') {

        const findSql = `
            SELECT
                c.complaint_id,
                c.status
            FROM complaints c
            JOIN students s
                ON c.student_id = s.student_id
            WHERE c.complaint_id = ?
              AND s.user_id = ?
        `;

        db.query(
            findSql,
            [complaintId, req.user.user_id],
            (findErr, findResults) => {

                if (findErr) {
                    console.error(
                        'Error checking complaint ownership:',
                        findErr
                    );

                    return res.status(500).json({
                        success: false,
                        message: 'Failed to verify complaint ownership'
                    });
                }

                if (findResults.length === 0) {
                    return res.status(404).json({
                        success: false,
                        message: 'Complaint not found'
                    });
                }

                const currentStatus =
                    findResults[0].status;

                const sql = `
                    UPDATE complaints
                    SET
                        category = ?,
                        title = ?,
                        description = ?,
                        priority = ?
                    WHERE complaint_id = ?
                `;

                const values = [
                    category,
                    title,
                    description,
                    priority || 'MEDIUM',
                    complaintId
                ];

                db.query(
                    sql,
                    values,
                    (err, result) => {

                        if (err) {
                            console.error(
                                'Error updating complaint:',
                                err
                            );

                            return res.status(500).json({
                                success: false,
                                message: 'Failed to update complaint',
                                error: err.message
                            });
                        }

                        res.json({
                            success: true,
                            message:
                                'Complaint updated successfully!',
                            status: currentStatus
                        });
                    }
                );
            }
        );

        return;
    }


    // =====================================
    // ADMIN / WARDEN
    // Can update any complaint
    // =====================================

    let resolvedDate = null;

    if (
        status === 'RESOLVED' ||
        status === 'CLOSED'
    ) {
        resolvedDate = new Date();
    }

    const sql = `
        UPDATE complaints
        SET
            category = ?,
            title = ?,
            description = ?,
            priority = ?,
            status = ?,
            resolved_at = ?
        WHERE complaint_id = ?
    `;

    const values = [
        category,
        title,
        description,
        priority || 'MEDIUM',
        status || 'PENDING',
        resolvedDate,
        complaintId
    ];

    db.query(sql, values, (err, result) => {

        if (err) {
            console.error('Error updating complaint:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to update complaint',
                error: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Complaint not found'
            });
        }

        res.json({
            success: true,
            message: 'Complaint updated successfully!'
        });
    });
});


// =====================================
// UPDATE COMPLAINT STATUS
// ADMIN / WARDEN ONLY
// =====================================

router.put('/:id/status', (req, res) => {

    // Students are not allowed to change complaint status
    if (req.user.role === 'STUDENT') {
        return res.status(403).json({
            success: false,
            message: 'Students cannot change complaint status'
        });
    }

    const complaintId = req.params.id;
    const { status } = req.body;

    const allowedStatuses = [
        'PENDING',
        'IN_PROGRESS',
        'RESOLVED',
        'CLOSED'
    ];

    if (!allowedStatuses.includes(status)) {
        return res.status(400).json({
            success: false,
            message: 'Invalid complaint status'
        });
    }

    let resolvedDate = null;

    if (
        status === 'RESOLVED' ||
        status === 'CLOSED'
    ) {
        resolvedDate = new Date();
    }

    const sql = `
        UPDATE complaints
        SET
            status = ?,
            resolved_at = ?
        WHERE complaint_id = ?
    `;

    db.query(
        sql,
        [status, resolvedDate, complaintId],
        (err, result) => {

            if (err) {
                console.error(
                    'Error updating complaint status:',
                    err
                );

                return res.status(500).json({
                    success: false,
                    message: 'Failed to update complaint status'
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Complaint not found'
                });
            }

            res.json({
                success: true,
                message:
                    'Complaint status updated successfully!'
            });
        }
    );
});


// =====================================
// DELETE COMPLAINT
// ADMIN / WARDEN -> CAN DELETE ANY
// STUDENT -> CAN DELETE ONLY OWN
// =====================================

router.delete('/:id', (req, res) => {

    const complaintId = req.params.id;

    let sql = `
        DELETE c
        FROM complaints c
        JOIN students s
            ON c.student_id = s.student_id
        WHERE c.complaint_id = ?
    `;

    const params = [complaintId];

    // Student can delete only own complaint
    if (req.user.role === 'STUDENT') {
        sql += `
            AND s.user_id = ?
        `;

        params.push(req.user.user_id);
    }

    db.query(sql, params, (err, result) => {

        if (err) {
            console.error('Error deleting complaint:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to delete complaint',
                error: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Complaint not found'
            });
        }

        res.json({
            success: true,
            message: 'Complaint deleted successfully!'
        });
    });
});


module.exports = router;
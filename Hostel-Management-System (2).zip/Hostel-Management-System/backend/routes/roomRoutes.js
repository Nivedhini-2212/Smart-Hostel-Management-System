const express = require('express');
const router = express.Router();

const db = require('../config/db');

// =====================================
// GET ALL ROOMS
// =====================================

router.get('/', (req, res) => {

    const sql = `
        SELECT
            r.room_id,
            r.hostel_id,
            h.hostel_name,
            r.room_number,
            r.floor,
            r.capacity,
            r.status
        FROM rooms r
        JOIN hostels h ON r.hostel_id = h.hostel_id
        ORDER BY r.hostel_id, r.floor, r.room_number
    `;

    db.query(sql, (err, results) => {

        if (err) {
            console.error('Error fetching rooms:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch rooms'
            });
        }

        res.json({
            success: true,
            rooms: results
        });
    });
});


// =====================================
// GET ROOM BY ID
// =====================================

router.get('/:id', (req, res) => {

    const roomId = req.params.id;

    const sql = `
        SELECT
            r.room_id,
            r.hostel_id,
            h.hostel_name,
            r.room_number,
            r.floor,
            r.capacity,
            r.status
        FROM rooms r
        JOIN hostels h ON r.hostel_id = h.hostel_id
        WHERE r.room_id = ?
    `;

    db.query(sql, [roomId], (err, results) => {

        if (err) {
            console.error('Error fetching room:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch room'
            });
        }

        if (results.length === 0) {

            return res.status(404).json({
                success: false,
                message: 'Room not found'
            });
        }

        res.json({
            success: true,
            room: results[0]
        });
    });
});


// =====================================
// ADD NEW ROOM
// =====================================

router.post('/', (req, res) => {

    const {
        hostel_id,
        room_number,
        floor,
        capacity,
        status
    } = req.body;


    if (
        !hostel_id ||
        !room_number ||
        floor === undefined ||
        !capacity
    ) {

        return res.status(400).json({
            success: false,
            message: 'Please provide hostel_id, room_number, floor and capacity'
        });
    }


    const sql = `
        INSERT INTO rooms
        (
            hostel_id,
            room_number,
            floor,
            capacity,
            status
        )
        VALUES (?, ?, ?, ?, ?)
    `;


    const values = [
        hostel_id,
        room_number,
        floor,
        capacity,
        status || 'AVAILABLE'
    ];


    db.query(sql, values, (err, result) => {

        if (err) {

            console.error('Error adding room:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to add room',
                error: err.message
            });
        }


        res.status(201).json({

            success: true,

            message: 'Room added successfully!',

            room_id: result.insertId
        });
    });
});


// =====================================
// UPDATE ROOM
// =====================================

router.put('/:id', (req, res) => {

    const roomId = req.params.id;

    const {
        hostel_id,
        room_number,
        floor,
        capacity,
        status
    } = req.body;


    if (
        !hostel_id ||
        !room_number ||
        floor === undefined ||
        !capacity
    ) {

        return res.status(400).json({
            success: false,
            message: 'Please provide hostel_id, room_number, floor and capacity'
        });
    }


    const sql = `
        UPDATE rooms
        SET
            hostel_id = ?,
            room_number = ?,
            floor = ?,
            capacity = ?,
            status = ?
        WHERE room_id = ?
    `;


    const values = [
        hostel_id,
        room_number,
        floor,
        capacity,
        status || 'AVAILABLE',
        roomId
    ];


    db.query(sql, values, (err, result) => {

        if (err) {

            console.error('Error updating room:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to update room',
                error: err.message
            });
        }


        if (result.affectedRows === 0) {

            return res.status(404).json({
                success: false,
                message: 'Room not found'
            });
        }


        res.json({

            success: true,

            message: 'Room updated successfully!'
        });
    });
});


// =====================================
// DELETE ROOM
// =====================================

router.delete('/:id', (req, res) => {

    const roomId = req.params.id;

    const sql = `
        DELETE FROM rooms
        WHERE room_id = ?
    `;


    db.query(sql, [roomId], (err, result) => {

        if (err) {

            console.error('Error deleting room:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to delete room',
                error: err.message
            });
        }


        if (result.affectedRows === 0) {

            return res.status(404).json({
                success: false,
                message: 'Room not found'
            });
        }


        res.json({

            success: true,

            message: 'Room deleted successfully!'
        });
    });
});


module.exports = router;
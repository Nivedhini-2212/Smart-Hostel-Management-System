const express = require('express');
const router = express.Router();

const db = require('../config/db');

// =====================================
// GET ALL LEAVE REQUESTS
// ADMIN / WARDEN -> ALL REQUESTS
// STUDENT -> ONLY OWN REQUESTS
// =====================================

router.get('/', (req, res) => {

    let sql = `
        SELECT
            l.leave_id,
            l.student_id,
            s.register_no,
            s.name AS student_name,
            s.department,
            l.from_date,
            l.to_date,
            l.reason,
            l.status,
            l.approved_by,
            u.username AS approved_by_user,
            l.created_at
        FROM leave_requests l
        JOIN students s
            ON l.student_id = s.student_id
        LEFT JOIN users u
            ON l.approved_by = u.user_id
    `;

    const params = [];

    // Student sees only their own leave requests
    if (req.user.role === 'STUDENT') {
        sql += `
            WHERE s.user_id = ?
        `;

        params.push(req.user.user_id);
    }

    sql += `
        ORDER BY l.created_at DESC
    `;

    db.query(sql, params, (err, results) => {

        if (err) {
            console.error('Error fetching leave requests:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch leave requests'
            });
        }

        res.json({
            success: true,
            leave_requests: results
        });
    });
});


// =====================================
// GET LEAVE REQUEST BY ID
// ADMIN / WARDEN -> ANY REQUEST
// STUDENT -> ONLY OWN REQUEST
// =====================================

router.get('/:id', (req, res) => {

    const leaveId = req.params.id;

    let sql = `
        SELECT
            l.leave_id,
            l.student_id,
            s.register_no,
            s.name AS student_name,
            s.department,
            l.from_date,
            l.to_date,
            l.reason,
            l.status,
            l.approved_by,
            u.username AS approved_by_user,
            l.created_at
        FROM leave_requests l
        JOIN students s
            ON l.student_id = s.student_id
        LEFT JOIN users u
            ON l.approved_by = u.user_id
        WHERE l.leave_id = ?
    `;

    const params = [leaveId];

    // Student can access only their own request
    if (req.user.role === 'STUDENT') {
        sql += `
            AND s.user_id = ?
        `;

        params.push(req.user.user_id);
    }

    db.query(sql, params, (err, results) => {

        if (err) {
            console.error('Error fetching leave request:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch leave request'
            });
        }

        if (results.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Leave request not found'
            });
        }

        res.json({
            success: true,
            leave_request: results[0]
        });
    });
});


// =====================================
// APPLY FOR LEAVE
// ADMIN / WARDEN -> CAN CREATE
// STUDENT -> ONLY FOR THEMSELVES
// =====================================

router.post('/', (req, res) => {

    const {
        student_id,
        from_date,
        to_date,
        reason
    } = req.body;

    if (!from_date || !to_date || !reason) {
        return res.status(400).json({
            success: false,
            message: 'Please provide from_date, to_date and reason'
        });
    }

    // Check date validity
    if (new Date(from_date) > new Date(to_date)) {
        return res.status(400).json({
            success: false,
            message: 'From date cannot be later than to date'
        });
    }


    // =====================================
    // STUDENT
    // Automatically identify logged-in student
    // =====================================

    if (req.user.role === 'STUDENT') {

        const findStudentSql = `
            SELECT student_id
            FROM students
            WHERE user_id = ?
            LIMIT 1
        `;

        db.query(
            findStudentSql,
            [req.user.user_id],
            (studentErr, studentResults) => {

                if (studentErr) {
                    console.error(
                        'Error finding student:',
                        studentErr
                    );

                    return res.status(500).json({
                        success: false,
                        message: 'Failed to identify student'
                    });
                }

                if (studentResults.length === 0) {
                    return res.status(404).json({
                        success: false,
                        message: 'Student profile not found'
                    });
                }

                const ownStudentId =
                    studentResults[0].student_id;

                const sql = `
                    INSERT INTO leave_requests
                    (
                        student_id,
                        from_date,
                        to_date,
                        reason,
                        status
                    )
                    VALUES (?, ?, ?, ?, 'PENDING')
                `;

                const values = [
                    ownStudentId,
                    from_date,
                    to_date,
                    reason
                ];

                db.query(
                    sql,
                    values,
                    (err, result) => {

                        if (err) {
                            console.error(
                                'Error creating leave request:',
                                err
                            );

                            return res.status(500).json({
                                success: false,
                                message:
                                    'Failed to create leave request',
                                error: err.message
                            });
                        }

                        res.status(201).json({
                            success: true,
                            message:
                                'Leave request submitted successfully!',
                            leave_id: result.insertId
                        });
                    }
                );
            }
        );

        return;
    }


    // =====================================
    // ADMIN / WARDEN
    // Can create for any student
    // =====================================

    if (!student_id) {
        return res.status(400).json({
            success: false,
            message: 'Please provide student_id'
        });
    }

    const sql = `
        INSERT INTO leave_requests
        (
            student_id,
            from_date,
            to_date,
            reason,
            status
        )
        VALUES (?, ?, ?, ?, 'PENDING')
    `;

    const values = [
        student_id,
        from_date,
        to_date,
        reason
    ];

    db.query(sql, values, (err, result) => {

        if (err) {
            console.error('Error creating leave request:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to create leave request',
                error: err.message
            });
        }

        res.status(201).json({
            success: true,
            message: 'Leave request submitted successfully!',
            leave_id: result.insertId
        });
    });
});


// =====================================
// UPDATE LEAVE REQUEST
// ADMIN / WARDEN -> CAN UPDATE
// STUDENT -> ONLY OWN REQUEST
// STUDENT CANNOT CHANGE STATUS
// =====================================

router.put('/:id', (req, res) => {

    const leaveId = req.params.id;

    const {
        from_date,
        to_date,
        reason,
        status
    } = req.body;

    if (!from_date || !to_date || !reason) {
        return res.status(400).json({
            success: false,
            message: 'Please provide from_date, to_date and reason'
        });
    }

    if (new Date(from_date) > new Date(to_date)) {
        return res.status(400).json({
            success: false,
            message: 'From date cannot be later than to date'
        });
    }


    // =====================================
    // STUDENT
    // Can edit only own request
    // Cannot change status
    // =====================================

    if (req.user.role === 'STUDENT') {

        const checkSql = `
            SELECT l.leave_id
            FROM leave_requests l
            JOIN students s
                ON l.student_id = s.student_id
            WHERE l.leave_id = ?
              AND s.user_id = ?
        `;

        db.query(
            checkSql,
            [leaveId, req.user.user_id],
            (checkErr, checkResults) => {

                if (checkErr) {
                    console.error(
                        'Error checking leave ownership:',
                        checkErr
                    );

                    return res.status(500).json({
                        success: false,
                        message:
                            'Failed to verify leave request ownership'
                    });
                }

                if (checkResults.length === 0) {
                    return res.status(404).json({
                        success: false,
                        message: 'Leave request not found'
                    });
                }

                const sql = `
                    UPDATE leave_requests
                    SET
                        from_date = ?,
                        to_date = ?,
                        reason = ?
                    WHERE leave_id = ?
                `;

                const values = [
                    from_date,
                    to_date,
                    reason,
                    leaveId
                ];

                db.query(
                    sql,
                    values,
                    (err, result) => {

                        if (err) {
                            console.error(
                                'Error updating leave request:',
                                err
                            );

                            return res.status(500).json({
                                success: false,
                                message:
                                    'Failed to update leave request'
                            });
                        }

                        res.json({
                            success: true,
                            message:
                                'Leave request updated successfully!'
                        });
                    }
                );
            }
        );

        return;
    }


    // =====================================
    // ADMIN / WARDEN
    // Can update any request
    // =====================================

    const allowedStatuses = [
        'PENDING',
        'APPROVED',
        'REJECTED',
        'CANCELLED'
    ];

    const finalStatus = status || 'PENDING';

    if (!allowedStatuses.includes(finalStatus)) {
        return res.status(400).json({
            success: false,
            message: 'Invalid leave status'
        });
    }

    const sql = `
        UPDATE leave_requests
        SET
            from_date = ?,
            to_date = ?,
            reason = ?,
            status = ?
        WHERE leave_id = ?
    `;

    const values = [
        from_date,
        to_date,
        reason,
        finalStatus,
        leaveId
    ];

    db.query(sql, values, (err, result) => {

        if (err) {
            console.error('Error updating leave request:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to update leave request',
                error: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Leave request not found'
            });
        }

        res.json({
            success: true,
            message: 'Leave request updated successfully!'
        });
    });
});


// =====================================
// APPROVE / REJECT / CANCEL LEAVE
// ADMIN / WARDEN ONLY
// =====================================

router.put('/:id/status', (req, res) => {

    // Students cannot approve/reject/cancel through this route
    if (req.user.role === 'STUDENT') {
        return res.status(403).json({
            success: false,
            message: 'Students cannot change leave request status'
        });
    }

    const leaveId = req.params.id;

    const {
        status
    } = req.body;

    const allowedStatuses = [
        'PENDING',
        'APPROVED',
        'REJECTED',
        'CANCELLED'
    ];

    if (!allowedStatuses.includes(status)) {
        return res.status(400).json({
            success: false,
            message: 'Invalid leave status'
        });
    }

    // The logged-in admin/warden becomes approver
    const approvedBy = req.user.user_id;

    const sql = `
        UPDATE leave_requests
        SET
            status = ?,
            approved_by = ?
        WHERE leave_id = ?
    `;

    db.query(
        sql,
        [
            status,
            approvedBy,
            leaveId
        ],
        (err, result) => {

            if (err) {
                console.error(
                    'Error updating leave status:',
                    err
                );

                return res.status(500).json({
                    success: false,
                    message:
                        'Failed to update leave status'
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Leave request not found'
                });
            }

            res.json({
                success: true,
                message:
                    `Leave request ${status.toLowerCase()} successfully!`
            });
        }
    );
});


// =====================================
// DELETE LEAVE REQUEST
// ADMIN / WARDEN -> ANY REQUEST
// STUDENT -> ONLY OWN REQUEST
// =====================================

router.delete('/:id', (req, res) => {

    const leaveId = req.params.id;

    let sql = `
        DELETE l
        FROM leave_requests l
        JOIN students s
            ON l.student_id = s.student_id
        WHERE l.leave_id = ?
    `;

    const params = [leaveId];

    // Student can delete only own request
    if (req.user.role === 'STUDENT') {
        sql += `
            AND s.user_id = ?
        `;

        params.push(req.user.user_id);
    }

    db.query(sql, params, (err, result) => {

        if (err) {
            console.error('Error deleting leave request:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to delete leave request',
                error: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Leave request not found'
            });
        }

        res.json({
            success: true,
            message: 'Leave request deleted successfully!'
        });
    });
});


module.exports = router;
const express = require('express');
const router = express.Router();

const db = require('../config/db');

// =====================================================
// GET ALL HOSTELS
// =====================================================

router.get('/', (req, res) => {

    const sql = 'SELECT * FROM hostels';

    db.query(sql, (err, results) => {

        if (err) {
            console.error('Error fetching hostels:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch hostels'
            });
        }

        res.json({
            success: true,
            hostels: results
        });
    });
});


// =====================================================
// GET HOSTEL BY ID
// =====================================================

router.get('/:id', (req, res) => {

    const hostelId = req.params.id;

    const sql = 'SELECT * FROM hostels WHERE hostel_id = ?';

    db.query(sql, [hostelId], (err, results) => {

        if (err) {
            console.error('Error fetching hostel:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch hostel'
            });
        }

        if (results.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Hostel not found'
            });
        }

        res.json({
            success: true,
            hostel: results[0]
        });
    });
});


// =====================================================
// ADD NEW HOSTEL
// =====================================================

router.post('/', (req, res) => {

    const {
        hostel_name,
        hostel_type,
        location,
        total_rooms,
        status
    } = req.body;

    if (!hostel_name || !hostel_type || !location) {

        return res.status(400).json({
            success: false,
            message: 'Please provide hostel name, type and location'
        });
    }

    const sql = `
        INSERT INTO hostels
        (
            hostel_name,
            hostel_type,
            location,
            total_rooms,
            status
        )
        VALUES (?, ?, ?, ?, ?)
    `;

    const values = [
        hostel_name,
        hostel_type,
        location,
        total_rooms || 0,
        status || 'ACTIVE'
    ];

    db.query(sql, values, (err, result) => {

        if (err) {
            console.error('Error adding hostel:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to add hostel',
                error: err.message
            });
        }

        res.status(201).json({
            success: true,
            message: 'Hostel added successfully!',
            hostel_id: result.insertId
        });
    });
});


// =====================================================
// UPDATE HOSTEL
// =====================================================

router.put('/:id', (req, res) => {

    const hostelId = req.params.id;

    const {
        hostel_name,
        hostel_type,
        location,
        total_rooms,
        status
    } = req.body;

    if (!hostel_name || !hostel_type || !location) {

        return res.status(400).json({
            success: false,
            message: 'Please provide hostel name, type and location'
        });
    }

    const sql = `
        UPDATE hostels
        SET
            hostel_name = ?,
            hostel_type = ?,
            location = ?,
            total_rooms = ?,
            status = ?
        WHERE hostel_id = ?
    `;

    const values = [
        hostel_name,
        hostel_type,
        location,
        total_rooms || 0,
        status || 'ACTIVE',
        hostelId
    ];

    db.query(sql, values, (err, result) => {

        if (err) {
            console.error('Error updating hostel:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to update hostel',
                error: err.message
            });
        }

        if (result.affectedRows === 0) {

            return res.status(404).json({
                success: false,
                message: 'Hostel not found'
            });
        }

        res.json({
            success: true,
            message: 'Hostel updated successfully!'
        });
    });
});


// =====================================================
// DELETE HOSTEL
// =====================================================

router.delete('/:id', (req, res) => {

    const hostelId = req.params.id;

    const sql = 'DELETE FROM hostels WHERE hostel_id = ?';

    db.query(sql, [hostelId], (err, result) => {

        if (err) {
            console.error('Error deleting hostel:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to delete hostel',
                error: err.message
            });
        }

        if (result.affectedRows === 0) {

            return res.status(404).json({
                success: false,
                message: 'Hostel not found'
            });
        }

        res.json({
            success: true,
            message: 'Hostel deleted successfully!'
        });
    });
});


module.exports = router;
const express = require('express');
const router = express.Router();

const db = require('../config/db');

// =====================================
// GET ALL VISITORS
// ADMIN / WARDEN -> ALL VISITORS
// STUDENT -> ONLY OWN VISITORS
// =====================================

router.get('/', (req, res) => {

    let sql = `
        SELECT
            v.visitor_id,
            v.student_id,
            s.register_no,
            s.name AS student_name,
            v.visitor_name,
            v.relationship,
            v.phone,
            v.visit_date,
            v.entry_time,
            v.exit_time,
            v.status
        FROM visitors v
        JOIN students s
            ON v.student_id = s.student_id
    `;

    const params = [];

    // Student sees only their own visitors
    if (req.user.role === 'STUDENT') {
        sql += `
            WHERE s.user_id = ?
        `;

        params.push(req.user.user_id);
    }

    sql += `
        ORDER BY v.visit_date DESC, v.visitor_id DESC
    `;

    db.query(sql, params, (err, results) => {

        if (err) {
            console.error('Error fetching visitors:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch visitors'
            });
        }

        res.json({
            success: true,
            visitors: results
        });
    });
});


// =====================================
// GET VISITOR BY ID
// ADMIN / WARDEN -> ANY VISITOR
// STUDENT -> ONLY OWN VISITOR
// =====================================

router.get('/:id', (req, res) => {

    const visitorId = req.params.id;

    let sql = `
        SELECT
            v.visitor_id,
            v.student_id,
            s.register_no,
            s.name AS student_name,
            v.visitor_name,
            v.relationship,
            v.phone,
            v.visit_date,
            v.entry_time,
            v.exit_time,
            v.status
        FROM visitors v
        JOIN students s
            ON v.student_id = s.student_id
        WHERE v.visitor_id = ?
    `;

    const params = [visitorId];

    // Student can access only their own visitor
    if (req.user.role === 'STUDENT') {
        sql += `
            AND s.user_id = ?
        `;

        params.push(req.user.user_id);
    }

    db.query(sql, params, (err, results) => {

        if (err) {
            console.error('Error fetching visitor:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch visitor'
            });
        }

        if (results.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Visitor not found'
            });
        }

        res.json({
            success: true,
            visitor: results[0]
        });
    });
});


// =====================================
// ADD NEW VISITOR
// ADMIN / WARDEN -> CAN ADD FOR ANY STUDENT
// STUDENT -> CAN ADD ONLY FOR THEMSELVES
// =====================================

router.post('/', (req, res) => {

    const {
        student_id,
        visitor_name,
        relationship,
        phone,
        visit_date,
        entry_time,
        exit_time,
        status
    } = req.body;

    if (
        !visitor_name ||
        !relationship ||
        !phone ||
        !visit_date
    ) {
        return res.status(400).json({
            success: false,
            message:
                'Please provide visitor_name, relationship, phone and visit_date'
        });
    }


    // =====================================
    // STUDENT
    // Automatically identify logged-in student
    // =====================================

    if (req.user.role === 'STUDENT') {

        const findStudentSql = `
            SELECT student_id
            FROM students
            WHERE user_id = ?
            LIMIT 1
        `;

        db.query(
            findStudentSql,
            [req.user.user_id],
            (studentErr, studentResults) => {

                if (studentErr) {
                    console.error(
                        'Error finding student:',
                        studentErr
                    );

                    return res.status(500).json({
                        success: false,
                        message: 'Failed to identify student'
                    });
                }

                if (studentResults.length === 0) {
                    return res.status(404).json({
                        success: false,
                        message: 'Student profile not found'
                    });
                }

                const ownStudentId =
                    studentResults[0].student_id;

                const sql = `
                    INSERT INTO visitors
                    (
                        student_id,
                        visitor_name,
                        relationship,
                        phone,
                        visit_date,
                        entry_time,
                        exit_time,
                        status
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                `;

                const values = [
                    ownStudentId,
                    visitor_name,
                    relationship,
                    phone,
                    visit_date,
                    entry_time || null,
                    exit_time || null,
                    'PENDING'
                ];

                db.query(
                    sql,
                    values,
                    (err, result) => {

                        if (err) {
                            console.error(
                                'Error adding visitor:',
                                err
                            );

                            return res.status(500).json({
                                success: false,
                                message: 'Failed to add visitor',
                                error: err.message
                            });
                        }

                        res.status(201).json({
                            success: true,
                            message: 'Visitor added successfully!',
                            visitor_id: result.insertId
                        });
                    }
                );
            }
        );

        return;
    }


    // =====================================
    // ADMIN / WARDEN
    // Can add visitor for any student
    // =====================================

    if (!student_id) {
        return res.status(400).json({
            success: false,
            message: 'Please provide student_id'
        });
    }

    const sql = `
        INSERT INTO visitors
        (
            student_id,
            visitor_name,
            relationship,
            phone,
            visit_date,
            entry_time,
            exit_time,
            status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
        student_id,
        visitor_name,
        relationship,
        phone,
        visit_date,
        entry_time || null,
        exit_time || null,
        status || 'PENDING'
    ];

    db.query(sql, values, (err, result) => {

        if (err) {
            console.error('Error adding visitor:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to add visitor',
                error: err.message
            });
        }

        res.status(201).json({
            success: true,
            message: 'Visitor added successfully!',
            visitor_id: result.insertId
        });
    });
});


// =====================================
// UPDATE VISITOR
// ADMIN / WARDEN -> CAN UPDATE ANY
// STUDENT -> ONLY OWN VISITOR
// STUDENT CANNOT CHANGE STATUS
// =====================================

router.put('/:id', (req, res) => {

    const visitorId = req.params.id;

    const {
        visitor_name,
        relationship,
        phone,
        visit_date,
        entry_time,
        exit_time,
        status
    } = req.body;

    if (
        !visitor_name ||
        !relationship ||
        !phone ||
        !visit_date
    ) {
        return res.status(400).json({
            success: false,
            message:
                'Please provide visitor_name, relationship, phone and visit_date'
        });
    }


    // =====================================
    // STUDENT
    // Can edit only own visitor
    // Cannot change status
    // =====================================

    if (req.user.role === 'STUDENT') {

        const checkSql = `
            SELECT v.visitor_id
            FROM visitors v
            JOIN students s
                ON v.student_id = s.student_id
            WHERE v.visitor_id = ?
              AND s.user_id = ?
        `;

        db.query(
            checkSql,
            [visitorId, req.user.user_id],
            (checkErr, checkResults) => {

                if (checkErr) {
                    console.error(
                        'Error checking visitor ownership:',
                        checkErr
                    );

                    return res.status(500).json({
                        success: false,
                        message:
                            'Failed to verify visitor ownership'
                    });
                }

                if (checkResults.length === 0) {
                    return res.status(404).json({
                        success: false,
                        message: 'Visitor not found'
                    });
                }

                const sql = `
                    UPDATE visitors
                    SET
                        visitor_name = ?,
                        relationship = ?,
                        phone = ?,
                        visit_date = ?,
                        entry_time = ?,
                        exit_time = ?
                    WHERE visitor_id = ?
                `;

                const values = [
                    visitor_name,
                    relationship,
                    phone,
                    visit_date,
                    entry_time || null,
                    exit_time || null,
                    visitorId
                ];

                db.query(
                    sql,
                    values,
                    (err, result) => {

                        if (err) {
                            console.error(
                                'Error updating visitor:',
                                err
                            );

                            return res.status(500).json({
                                success: false,
                                message:
                                    'Failed to update visitor'
                            });
                        }

                        res.json({
                            success: true,
                            message:
                                'Visitor updated successfully!'
                        });
                    }
                );
            }
        );

        return;
    }


    // =====================================
    // ADMIN / WARDEN
    // Can update any visitor
    // =====================================

    const allowedStatuses = [
        'PENDING',
        'APPROVED',
        'REJECTED',
        'COMPLETED'
    ];

    const finalStatus = status || 'PENDING';

    if (!allowedStatuses.includes(finalStatus)) {
        return res.status(400).json({
            success: false,
            message: 'Invalid visitor status'
        });
    }

    const sql = `
        UPDATE visitors
        SET
            visitor_name = ?,
            relationship = ?,
            phone = ?,
            visit_date = ?,
            entry_time = ?,
            exit_time = ?,
            status = ?
        WHERE visitor_id = ?
    `;

    const values = [
        visitor_name,
        relationship,
        phone,
        visit_date,
        entry_time || null,
        exit_time || null,
        finalStatus,
        visitorId
    ];

    db.query(sql, values, (err, result) => {

        if (err) {
            console.error('Error updating visitor:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to update visitor',
                error: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Visitor not found'
            });
        }

        res.json({
            success: true,
            message: 'Visitor updated successfully!'
        });
    });
});


// =====================================
// UPDATE VISITOR STATUS
// ADMIN / WARDEN ONLY
// =====================================

router.put('/:id/status', (req, res) => {

    // Students cannot change visitor status
    if (req.user.role === 'STUDENT') {
        return res.status(403).json({
            success: false,
            message: 'Students cannot change visitor status'
        });
    }

    const visitorId = req.params.id;
    const { status } = req.body;

    const allowedStatuses = [
        'PENDING',
        'APPROVED',
        'REJECTED',
        'COMPLETED'
    ];

    if (!allowedStatuses.includes(status)) {
        return res.status(400).json({
            success: false,
            message: 'Invalid visitor status'
        });
    }

    const sql = `
        UPDATE visitors
        SET status = ?
        WHERE visitor_id = ?
    `;

    db.query(
        sql,
        [status, visitorId],
        (err, result) => {

            if (err) {
                console.error(
                    'Error updating visitor status:',
                    err
                );

                return res.status(500).json({
                    success: false,
                    message: 'Failed to update visitor status'
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Visitor not found'
                });
            }

            res.json({
                success: true,
                message:
                    'Visitor status updated successfully!'
            });
        }
    );
});


// =====================================
// DELETE VISITOR
// ADMIN / WARDEN -> ANY VISITOR
// STUDENT -> ONLY OWN VISITOR
// =====================================

router.delete('/:id', (req, res) => {

    const visitorId = req.params.id;

    let sql = `
        DELETE v
        FROM visitors v
        JOIN students s
            ON v.student_id = s.student_id
        WHERE v.visitor_id = ?
    `;

    const params = [visitorId];

    // Student can delete only own visitor
    if (req.user.role === 'STUDENT') {
        sql += `
            AND s.user_id = ?
        `;

        params.push(req.user.user_id);
    }

    db.query(sql, params, (err, result) => {

        if (err) {
            console.error('Error deleting visitor:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to delete visitor',
                error: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Visitor not found'
            });
        }

        res.json({
            success: true,
            message: 'Visitor deleted successfully!'
        });
    });
});


module.exports = router;
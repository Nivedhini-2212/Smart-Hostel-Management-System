const express = require("express");
const router = express.Router();

const db = require("../config/db");

// =====================================
// GET LOGGED-IN STUDENT PROFILE
// =====================================

router.get("/", (req, res) => {

    const userId = req.user.user_id;

    const sql = `
        SELECT
            student_id,
            user_id,
            register_no,
            name,
            department,
            year,
            gender,
            phone,
            email,
            parent_name,
            parent_phone,
            address,
            admission_date,
            status
        FROM students
        WHERE user_id = ?
        LIMIT 1
    `;

    db.query(sql, [userId], (err, results) => {

        if (err) {
            console.error("Error fetching student profile:", err);

            return res.status(500).json({
                success: false,
                message: "Failed to fetch student profile"
            });
        }

        if (results.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Student profile not found"
            });
        }

        res.json({
            success: true,
            data: results
        });
    });
});

module.exports = router;
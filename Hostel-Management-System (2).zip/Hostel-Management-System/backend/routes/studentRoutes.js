const express = require('express');
const router = express.Router();

const db = require('../config/db');

// =====================================================
// GET ALL STUDENTS
// =====================================================

router.get('/', (req, res) => {
    const sql = 'SELECT * FROM students';

    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error fetching students:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch students'
            });
        }

        res.json({
            success: true,
            students: results
        });
    });
});


// =====================================================
// GET STUDENT BY ID
// =====================================================

router.get('/:id', (req, res) => {
    const studentId = req.params.id;

    const sql = 'SELECT * FROM students WHERE student_id = ?';

    db.query(sql, [studentId], (err, results) => {
        if (err) {
            console.error('Error fetching student:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch student'
            });
        }

        if (results.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        res.json({
            success: true,
            student: results[0]
        });
    });
});


// =====================================================
// ADD NEW STUDENT
// =====================================================

router.post('/', (req, res) => {

    const {
        user_id,
        register_no,
        name,
        department,
        year,
        gender,
        phone,
        email,
        parent_name,
        parent_phone,
        address,
        admission_date,
        status
    } = req.body;

    // Basic validation
    if (
        !user_id ||
        !register_no ||
        !name ||
        !department ||
        !year ||
        !gender ||
        !phone ||
        !parent_name ||
        !parent_phone ||
        !admission_date
    ) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all required student details'
        });
    }

    const sql = `
        INSERT INTO students
        (
            user_id,
            register_no,
            name,
            department,
            year,
            gender,
            phone,
            email,
            parent_name,
            parent_phone,
            address,
            admission_date,
            status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
        user_id,
        register_no,
        name,
        department,
        year,
        gender,
        phone,
        email || null,
        parent_name,
        parent_phone,
        address || null,
        admission_date,
        status || 'ACTIVE'
    ];

    db.query(sql, values, (err, result) => {

        if (err) {
            console.error('Error adding student:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to add student',
                error: err.message
            });
        }

        res.status(201).json({
            success: true,
            message: 'Student added successfully!',
            student_id: result.insertId
        });
    });
});

// =====================================================
// UPDATE STUDENT
// =====================================================

router.put('/:id', (req, res) => {

    const studentId = req.params.id;

    const {
        register_no,
        name,
        department,
        year,
        gender,
        phone,
        email,
        parent_name,
        parent_phone,
        address,
        admission_date,
        status
    } = req.body;

    // Basic validation
    if (
        !register_no ||
        !name ||
        !department ||
        !year ||
        !gender ||
        !phone ||
        !parent_name ||
        !parent_phone ||
        !admission_date
    ) {
        return res.status(400).json({
            success: false,
            message: 'Please provide all required student details'
        });
    }

    const sql = `
        UPDATE students
        SET
            register_no = ?,
            name = ?,
            department = ?,
            year = ?,
            gender = ?,
            phone = ?,
            email = ?,
            parent_name = ?,
            parent_phone = ?,
            address = ?,
            admission_date = ?,
            status = ?
        WHERE student_id = ?
    `;

    const values = [
        register_no,
        name,
        department,
        year,
        gender,
        phone,
        email || null,
        parent_name,
        parent_phone,
        address || null,
        admission_date,
        status || 'ACTIVE',
        studentId
    ];

    db.query(sql, values, (err, result) => {

        if (err) {
            console.error('Error updating student:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to update student',
                error: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        res.json({
            success: true,
            message: 'Student updated successfully!'
        });
    });
});

// =====================================================
// DELETE STUDENT
// =====================================================

router.delete('/:id', (req, res) => {

    const studentId = req.params.id;

    const sql = 'DELETE FROM students WHERE student_id = ?';

    db.query(sql, [studentId], (err, result) => {

        if (err) {
            console.error('Error deleting student:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to delete student',
                error: err.message
            });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: 'Student not found'
            });
        }

        res.json({
            success: true,
            message: 'Student deleted successfully!'
        });
    });
});
module.exports = router;

const express = require('express');
const router = express.Router();
const db = require('../config/db');

// =====================================================
// GET ALL NOTICES
// ADMIN / WARDEN / STUDENT -> CAN VIEW
// =====================================================

router.get('/', (req, res) => {

    const sql = `
        SELECT
            n.notice_id,
            n.title,
            n.content,
            n.created_by,
            u.username AS created_by_user,
            n.created_at,
            n.expiry_date,
            n.status
        FROM notices n
        JOIN users u
            ON n.created_by = u.user_id
        ORDER BY n.created_at DESC
    `;

    db.query(sql, (err, results) => {

        if (err) {
            console.error('Error fetching notices:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch notices'
            });
        }

        res.json({
            success: true,
            count: results.length,
            data: results
        });
    });
});


// =====================================================
// GET NOTICE BY ID
// ADMIN / WARDEN / STUDENT -> CAN VIEW
// =====================================================

router.get('/:id', (req, res) => {

    const sql = `
        SELECT
            n.notice_id,
            n.title,
            n.content,
            n.created_by,
            u.username AS created_by_user,
            n.created_at,
            n.expiry_date,
            n.status
        FROM notices n
        JOIN users u
            ON n.created_by = u.user_id
        WHERE n.notice_id = ?
    `;

    db.query(sql, [req.params.id], (err, results) => {

        if (err) {
            console.error('Error fetching notice:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch notice'
            });
        }

        if (results.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Notice not found'
            });
        }

        res.json({
            success: true,
            data: results[0]
        });
    });
});


// =====================================================
// CREATE NOTICE
// ADMIN / WARDEN ONLY
// =====================================================

router.post('/', (req, res) => {

    // Students cannot create notices
    if (req.user.role === 'STUDENT') {

        return res.status(403).json({
            success: false,
            message: 'Students cannot create notices'
        });
    }

    const {
        title,
        content,
        expiry_date,
        status
    } = req.body;

    if (!title || !content) {

        return res.status(400).json({
            success: false,
            message: 'title and content are required'
        });
    }

    // Use the logged-in admin/warden as creator
    const createdBy = req.user.user_id;

    const allowedStatuses = [
        'DRAFT',
        'PUBLISHED',
        'EXPIRED'
    ];

    const finalStatus = status || 'PUBLISHED';

    if (!allowedStatuses.includes(finalStatus)) {

        return res.status(400).json({
            success: false,
            message:
                'Invalid status. Use DRAFT, PUBLISHED or EXPIRED'
        });
    }

    const sql = `
        INSERT INTO notices
        (
            title,
            content,
            created_by,
            expiry_date,
            status
        )
        VALUES (?, ?, ?, ?, ?)
    `;

    db.query(
        sql,
        [
            title,
            content,
            createdBy,
            expiry_date || null,
            finalStatus
        ],
        (err, result) => {

            if (err) {
                console.error('Error creating notice:', err);

                return res.status(500).json({
                    success: false,
                    message: 'Failed to create notice'
                });
            }

            res.status(201).json({
                success: true,
                message: 'Notice created successfully',
                notice_id: result.insertId
            });
        }
    );
});


// =====================================================
// UPDATE NOTICE
// ADMIN / WARDEN ONLY
// =====================================================

router.put('/:id', (req, res) => {

    // Students cannot edit notices
    if (req.user.role === 'STUDENT') {

        return res.status(403).json({
            success: false,
            message: 'Students cannot edit notices'
        });
    }

    const {
        title,
        content,
        expiry_date,
        status
    } = req.body;

    if (!title || !content) {

        return res.status(400).json({
            success: false,
            message: 'title and content are required'
        });
    }

    const allowedStatuses = [
        'DRAFT',
        'PUBLISHED',
        'EXPIRED'
    ];

    const finalStatus = status || 'PUBLISHED';

    if (!allowedStatuses.includes(finalStatus)) {

        return res.status(400).json({
            success: false,
            message:
                'Invalid status. Use DRAFT, PUBLISHED or EXPIRED'
        });
    }

    const sql = `
        UPDATE notices
        SET
            title = ?,
            content = ?,
            expiry_date = ?,
            status = ?
        WHERE notice_id = ?
    `;

    db.query(
        sql,
        [
            title,
            content,
            expiry_date || null,
            finalStatus,
            req.params.id
        ],
        (err, result) => {

            if (err) {
                console.error('Error updating notice:', err);

                return res.status(500).json({
                    success: false,
                    message: 'Failed to update notice'
                });
            }

            if (result.affectedRows === 0) {

                return res.status(404).json({
                    success: false,
                    message: 'Notice not found'
                });
            }

            res.json({
                success: true,
                message: 'Notice updated successfully'
            });
        }
    );
});


// =====================================================
// UPDATE NOTICE STATUS
// ADMIN / WARDEN ONLY
// =====================================================

router.put('/:id/status', (req, res) => {

    // Students cannot change notice status
    if (req.user.role === 'STUDENT') {

        return res.status(403).json({
            success: false,
            message: 'Students cannot change notice status'
        });
    }

    const { status } = req.body;

    const allowedStatuses = [
        'DRAFT',
        'PUBLISHED',
        'EXPIRED'
    ];

    if (!status || !allowedStatuses.includes(status)) {

        return res.status(400).json({
            success: false,
            message:
                'Invalid status. Use DRAFT, PUBLISHED or EXPIRED'
        });
    }

    const sql = `
        UPDATE notices
        SET status = ?
        WHERE notice_id = ?
    `;

    db.query(
        sql,
        [status, req.params.id],
        (err, result) => {

            if (err) {
                console.error(
                    'Error updating notice status:',
                    err
                );

                return res.status(500).json({
                    success: false,
                    message: 'Failed to update notice status'
                });
            }

            if (result.affectedRows === 0) {

                return res.status(404).json({
                    success: false,
                    message: 'Notice not found'
                });
            }

            res.json({
                success: true,
                message:
                    'Notice status updated successfully'
            });
        }
    );
});


// =====================================================
// DELETE NOTICE
// ADMIN / WARDEN ONLY
// =====================================================

router.delete('/:id', (req, res) => {

    // Students cannot delete notices
    if (req.user.role === 'STUDENT') {

        return res.status(403).json({
            success: false,
            message: 'Students cannot delete notices'
        });
    }

    const sql = `
        DELETE FROM notices
        WHERE notice_id = ?
    `;

    db.query(
        sql,
        [req.params.id],
        (err, result) => {

            if (err) {
                console.error(
                    'Error deleting notice:',
                    err
                );

                return res.status(500).json({
                    success: false,
                    message: 'Failed to delete notice'
                });
            }

            if (result.affectedRows === 0) {

                return res.status(404).json({
                    success: false,
                    message: 'Notice not found'
                });
            }

            res.json({
                success: true,
                message: 'Notice deleted successfully'
            });
        }
    );
});


module.exports = router;
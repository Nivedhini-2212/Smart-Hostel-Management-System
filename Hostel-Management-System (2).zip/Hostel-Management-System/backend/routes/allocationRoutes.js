const express = require("express");
const router = express.Router();

const db = require("../config/db");

// =====================================
// GET ALL / STUDENT'S ALLOCATIONS
// =====================================

router.get("/", (req, res) => {

    let sql = `
        SELECT
            ra.allocation_id,
            ra.student_id,
            s.register_no,
            s.name AS student_name,

            ra.room_id,
            r.room_number,

            ra.bed_id,
            b.bed_number,

            h.hostel_id,
            h.hostel_name,

            ra.allocation_date,
            ra.vacate_date,
            ra.status

        FROM room_allocations ra

        JOIN students s
            ON ra.student_id = s.student_id

        JOIN rooms r
            ON ra.room_id = r.room_id

        JOIN beds b
            ON ra.bed_id = b.bed_id

        JOIN hostels h
            ON r.hostel_id = h.hostel_id
    `;

    const params = [];

    // =====================================
    // STUDENT → ONLY OWN ALLOCATION
    // =====================================

    if (req.user.role === "STUDENT") {
        sql += `
            WHERE s.user_id = ?
        `;

        params.push(req.user.user_id);
    }

    sql += `
        ORDER BY ra.allocation_id DESC
    `;


    db.query(sql, params, (err, results) => {

        if (err) {

            console.error("Error fetching allocations:", err);

            return res.status(500).json({
                success: false,
                message: "Failed to fetch allocations"
            });
        }


        res.json({
            success: true,
            allocations: results
        });

    });

});


// =====================================
// GET ALLOCATION BY ID
// =====================================

router.get("/:id", (req, res) => {

    const allocationId = req.params.id;

    let sql = `
        SELECT
            ra.allocation_id,
            ra.student_id,
            s.register_no,
            s.name AS student_name,

            ra.room_id,
            r.room_number,

            ra.bed_id,
            b.bed_number,

            h.hostel_id,
            h.hostel_name,

            ra.allocation_date,
            ra.vacate_date,
            ra.status

        FROM room_allocations ra

        JOIN students s
            ON ra.student_id = s.student_id

        JOIN rooms r
            ON ra.room_id = r.room_id

        JOIN beds b
            ON ra.bed_id = b.bed_id

        JOIN hostels h
            ON r.hostel_id = h.hostel_id

        WHERE ra.allocation_id = ?
    `;

    const params = [allocationId];


    // STUDENT → can only access own allocation
    if (req.user.role === "STUDENT") {

        sql += `
            AND s.user_id = ?
        `;

        params.push(req.user.user_id);
    }


    db.query(sql, params, (err, results) => {

        if (err) {

            console.error("Error fetching allocation:", err);

            return res.status(500).json({
                success: false,
                message: "Failed to fetch allocation"
            });
        }


        if (results.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Allocation not found"
            });
        }


        res.json({
            success: true,
            allocation: results[0]
        });

    });

});


// =====================================
// CREATE NEW ROOM ALLOCATION
// =====================================

router.post("/", (req, res) => {

    // STUDENTS CANNOT CREATE ALLOCATIONS
    if (req.user.role === "STUDENT") {

        return res.status(403).json({
            success: false,
            message: "Students are not allowed to create room allocations"
        });
    }


    const {
        student_id,
        room_id,
        bed_id,
        allocation_date
    } = req.body;


    // =====================================
    // VALIDATE INPUT
    // =====================================

    if (
        !student_id ||
        !room_id ||
        !bed_id ||
        !allocation_date
    ) {

        return res.status(400).json({
            success: false,
            message:
                "Please provide student_id, room_id, bed_id and allocation_date"
        });
    }


    // =====================================
    // CHECK STUDENT
    // =====================================

    const studentSql = `
        SELECT student_id
        FROM students
        WHERE student_id = ?
        AND status = "ACTIVE"
    `;


    db.query(
        studentSql,
        [student_id],
        (err, studentResults) => {

            if (err) {

                console.error(err);

                return res.status(500).json({
                    success: false,
                    message: "Failed to check student"
                });
            }


            if (studentResults.length === 0) {

                return res.status(400).json({
                    success: false,
                    message: "Student not found or inactive"
                });
            }


            // =====================================
            // CHECK BED + ROOM
            // =====================================

            const bedSql = `
                SELECT
                    b.bed_id,
                    b.room_id,
                    b.status AS bed_status,

                    r.capacity,
                    r.status AS room_status

                FROM beds b

                JOIN rooms r
                    ON b.room_id = r.room_id

                WHERE b.bed_id = ?
            `;


            db.query(
                bedSql,
                [bed_id],
                (err, bedResults) => {

                    if (err) {

                        console.error(err);

                        return res.status(500).json({
                            success: false,
                            message: "Failed to check bed"
                        });
                    }


                    if (bedResults.length === 0) {

                        return res.status(400).json({
                            success: false,
                            message: "Bed not found"
                        });
                    }


                    const bed = bedResults[0];


                    // =====================================
                    // BED MUST BELONG TO SELECTED ROOM
                    // =====================================

                    if (
                        Number(bed.room_id) !==
                        Number(room_id)
                    ) {

                        return res.status(400).json({
                            success: false,
                            message:
                                "Selected bed does not belong to the selected room"
                        });
                    }


                    // =====================================
                    // CHECK BED AVAILABILITY
                    // =====================================

                    if (bed.bed_status !== "AVAILABLE") {

                        return res.status(400).json({
                            success: false,
                            message: "Selected bed is not available"
                        });
                    }


                    // =====================================
                    // CHECK ROOM AVAILABILITY
                    // =====================================

                    if (bed.room_status !== "AVAILABLE") {

                        return res.status(400).json({
                            success: false,
                            message: "Selected room is not available"
                        });
                    }


                    // =====================================
                    // CHECK EXISTING STUDENT ALLOCATION
                    // =====================================

                    const existingStudentSql = `
                        SELECT allocation_id
                        FROM room_allocations
                        WHERE student_id = ?
                        AND status = "ACTIVE"
                    `;


                    db.query(
                        existingStudentSql,
                        [student_id],
                        (err, existingStudentResults) => {

                            if (err) {

                                console.error(err);

                                return res.status(500).json({
                                    success: false,
                                    message:
                                        "Failed to check existing allocation"
                                });
                            }


                            if (
                                existingStudentResults.length > 0
                            ) {

                                return res.status(400).json({
                                    success: false,
                                    message:
                                        "Student already has an active room allocation"
                                });
                            }


                            // =====================================
                            // CREATE ALLOCATION
                            // =====================================

                            const allocationSql = `
                                INSERT INTO room_allocations
                                (
                                    student_id,
                                    room_id,
                                    bed_id,
                                    allocation_date,
                                    status
                                )
                                VALUES (?, ?, ?, ?, "ACTIVE")
                            `;


                            const values = [
                                student_id,
                                room_id,
                                bed_id,
                                allocation_date
                            ];


                            db.query(
                                allocationSql,
                                values,
                                (err, result) => {

                                    if (err) {

                                        console.error(
                                            "Error creating allocation:",
                                            err
                                        );

                                        return res.status(500).json({
                                            success: false,
                                            message:
                                                "Failed to create allocation",
                                            error: err.message
                                        });
                                    }


                                    // =====================================
                                    // UPDATE BED STATUS
                                    // =====================================

                                    const updateBedSql = `
                                        UPDATE beds
                                        SET status = "OCCUPIED"
                                        WHERE bed_id = ?
                                    `;


                                    db.query(
                                        updateBedSql,
                                        [bed_id],
                                        (err) => {

                                            if (err) {

                                                console.error(
                                                    "Error updating bed:",
                                                    err
                                                );

                                                return res.status(500).json({
                                                    success: false,
                                                    message:
                                                        "Allocation created but bed status update failed"
                                                });
                                            }


                                            res.status(201).json({

                                                success: true,

                                                message:
                                                    "Room allocated successfully!",

                                                allocation_id:
                                                    result.insertId

                                            });

                                        }
                                    );

                                }
                            );

                        }
                    );

                }
            );

        }
    );

});


// =====================================
// VACATE ROOM / BED
// =====================================

router.put("/:id/vacate", (req, res) => {

    // STUDENTS CANNOT VACATE
    if (req.user.role === "STUDENT") {

        return res.status(403).json({
            success: false,
            message: "Students are not allowed to vacate room allocations"
        });
    }


    const allocationId = req.params.id;

    const vacateDate =
        req.body.vacate_date ||
        new Date().toISOString().split("T")[0];


    // =====================================
    // FIND ALLOCATION
    // =====================================

    const findSql = `
        SELECT
            allocation_id,
            bed_id,
            status
        FROM room_allocations
        WHERE allocation_id = ?
    `;


    db.query(
        findSql,
        [allocationId],
        (err, results) => {

            if (err) {

                console.error(err);

                return res.status(500).json({
                    success: false,
                    message: "Failed to find allocation"
                });
            }


            if (results.length === 0) {

                return res.status(404).json({
                    success: false,
                    message: "Allocation not found"
                });
            }


            const allocation = results[0];


            if (allocation.status !== "ACTIVE") {

                return res.status(400).json({
                    success: false,
                    message: "Allocation is not active"
                });
            }


            // =====================================
            // UPDATE ALLOCATION
            // =====================================

            const updateAllocationSql = `
                UPDATE room_allocations
                SET
                    vacate_date = ?,
                    status = "VACATED"
                WHERE allocation_id = ?
            `;


            db.query(
                updateAllocationSql,
                [vacateDate, allocationId],
                (err) => {

                    if (err) {

                        console.error(err);

                        return res.status(500).json({
                            success: false,
                            message: "Failed to vacate allocation"
                        });
                    }


                    // =====================================
                    // MAKE BED AVAILABLE
                    // =====================================

                    const updateBedSql = `
                        UPDATE beds
                        SET status = "AVAILABLE"
                        WHERE bed_id = ?
                    `;


                    db.query(
                        updateBedSql,
                        [allocation.bed_id],
                        (err) => {

                            if (err) {

                                console.error(err);

                                return res.status(500).json({
                                    success: false,
                                    message:
                                        "Allocation vacated but bed status update failed"
                                });
                            }


                            res.json({
                                success: true,
                                message:
                                    "Student vacated successfully!"
                            });

                        }
                    );

                }
            );

        }
    );

});


// =====================================
// DELETE ALLOCATION
// =====================================

router.delete("/:id", (req, res) => {

    // STUDENTS CANNOT DELETE
    if (req.user.role === "STUDENT") {

        return res.status(403).json({
            success: false,
            message: "Students are not allowed to delete allocations"
        });
    }


    const allocationId = req.params.id;


    const sql = `
        DELETE FROM room_allocations
        WHERE allocation_id = ?
    `;


    db.query(
        sql,
        [allocationId],
        (err, result) => {

            if (err) {

                console.error("Error deleting allocation:", err);

                return res.status(500).json({
                    success: false,
                    message: "Failed to delete allocation",
                    error: err.message
                });
            }


            if (result.affectedRows === 0) {

                return res.status(404).json({
                    success: false,
                    message: "Allocation not found"
                });
            }


            res.json({
                success: true,
                message: "Allocation deleted successfully!"
            });

        }
    );

});


module.exports = router;
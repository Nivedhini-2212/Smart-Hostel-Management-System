const express = require('express');
const router = express.Router();

const db = require('../config/db');

// =====================================
// GET ALL BEDS
// =====================================

router.get('/', (req, res) => {

    const sql = `
        SELECT
            b.bed_id,
            b.room_id,
            r.room_number,
            r.hostel_id,
            h.hostel_name,
            b.bed_number,
            b.status
        FROM beds b
        JOIN rooms r ON b.room_id = r.room_id
        JOIN hostels h ON r.hostel_id = h.hostel_id
        ORDER BY r.room_id, b.bed_number
    `;


    db.query(sql, (err, results) => {

        if (err) {

            console.error('Error fetching beds:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch beds'
            });
        }


        res.json({

            success: true,

            beds: results
        });
    });
});


// =====================================
// GET BED BY ID
// =====================================

router.get('/:id', (req, res) => {

    const bedId = req.params.id;

    const sql = `
        SELECT
            b.bed_id,
            b.room_id,
            r.room_number,
            r.hostel_id,
            h.hostel_name,
            b.bed_number,
            b.status
        FROM beds b
        JOIN rooms r ON b.room_id = r.room_id
        JOIN hostels h ON r.hostel_id = h.hostel_id
        WHERE b.bed_id = ?
    `;


    db.query(sql, [bedId], (err, results) => {

        if (err) {

            console.error('Error fetching bed:', err);

            return res.status(500).json({
                success: false,
                message: 'Failed to fetch bed'
            });
        }


        if (results.length === 0) {

            return res.status(404).json({
                success: false,
                message: 'Bed not found'
            });
        }


        res.json({

            success: true,

            bed: results[0]
        });
    });
});


// =====================================
// ADD NEW BED
// =====================================

router.post('/', (req, res) => {

    const {
        room_id,
        bed_number,
        status
    } = req.body;


    if (!room_id || !bed_number) {

        return res.status(400).json({

            success: false,

            message: 'Please provide room_id and bed_number'
        });
    }


    const sql = `
        INSERT INTO beds
        (
            room_id,
            bed_number,
            status
        )
        VALUES (?, ?, ?)
    `;


    const values = [
        room_id,
        bed_number,
        status || 'AVAILABLE'
    ];


    db.query(sql, values, (err, result) => {

        if (err) {

            console.error('Error adding bed:', err);

            return res.status(500).json({

                success: false,

                message: 'Failed to add bed',

                error: err.message
            });
        }


        res.status(201).json({

            success: true,

            message: 'Bed added successfully!',

            bed_id: result.insertId
        });
    });
});


// =====================================
// UPDATE BED
// =====================================

router.put('/:id', (req, res) => {

    const bedId = req.params.id;

    const {
        room_id,
        bed_number,
        status
    } = req.body;


    if (!room_id || !bed_number) {

        return res.status(400).json({

            success: false,

            message: 'Please provide room_id and bed_number'
        });
    }


    const sql = `
        UPDATE beds
        SET
            room_id = ?,
            bed_number = ?,
            status = ?
        WHERE bed_id = ?
    `;


    const values = [
        room_id,
        bed_number,
        status || 'AVAILABLE',
        bedId
    ];


    db.query(sql, values, (err, result) => {

        if (err) {

            console.error('Error updating bed:', err);

            return res.status(500).json({

                success: false,

                message: 'Failed to update bed',

                error: err.message
            });
        }


        if (result.affectedRows === 0) {

            return res.status(404).json({

                success: false,

                message: 'Bed not found'
            });
        }


        res.json({

            success: true,

            message: 'Bed updated successfully!'
        });
    });
});


// =====================================
// DELETE BED
// =====================================

router.delete('/:id', (req, res) => {

    const bedId = req.params.id;

    const sql = `
        DELETE FROM beds
        WHERE bed_id = ?
    `;


    db.query(sql, [bedId], (err, result) => {

        if (err) {

            console.error('Error deleting bed:', err);

            return res.status(500).json({

                success: false,

                message: 'Failed to delete bed',

                error: err.message
            });
        }


        if (result.affectedRows === 0) {

            return res.status(404).json({

                success: false,

                message: 'Bed not found'
            });
        }


        res.json({

            success: true,

            message: 'Bed deleted successfully!'
        });
    });
});


module.exports = router;
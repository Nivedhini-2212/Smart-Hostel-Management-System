const express = require("express");
const router = express.Router();

const db = require("../config/db");

// =====================================
// GET FEES
// ADMIN / WARDEN → ALL FEES
// STUDENT → ONLY OWN FEES
// =====================================

router.get("/", (req, res) => {

    let sql = `
        SELECT
            f.fee_id,
            f.student_id,
            s.register_no,
            s.name AS student_name,
            f.fee_type,
            f.amount,
            f.due_date,
            f.paid_date,
            f.status
        FROM fees f
        JOIN students s
            ON f.student_id = s.student_id
    `;

    const params = [];

    // =====================================
    // STUDENT → ONLY THEIR OWN FEES
    // =====================================

    if (req.user.role === "STUDENT") {

        sql += `
            WHERE s.user_id = ?
        `;

        params.push(req.user.user_id);
    }

    sql += `
        ORDER BY f.due_date DESC
    `;


    db.query(sql, params, (err, results) => {

        if (err) {

            console.error("Error fetching fees:", err);

            return res.status(500).json({
                success: false,
                message: "Failed to fetch fees"
            });
        }


        res.json({
            success: true,
            fees: results
        });

    });

});


// =====================================
// GET FEE BY ID
// ADMIN / WARDEN → ANY FEE
// STUDENT → ONLY OWN FEE
// =====================================

router.get("/:id", (req, res) => {

    const feeId = req.params.id;

    let sql = `
        SELECT
            f.fee_id,
            f.student_id,
            s.register_no,
            s.name AS student_name,
            f.fee_type,
            f.amount,
            f.due_date,
            f.paid_date,
            f.status
        FROM fees f
        JOIN students s
            ON f.student_id = s.student_id
        WHERE f.fee_id = ?
    `;

    const params = [feeId];


    // =====================================
    // STUDENT → OWN FEE ONLY
    // =====================================

    if (req.user.role === "STUDENT") {

        sql += `
            AND s.user_id = ?
        `;

        params.push(req.user.user_id);
    }


    db.query(sql, params, (err, results) => {

        if (err) {

            console.error("Error fetching fee:", err);

            return res.status(500).json({
                success: false,
                message: "Failed to fetch fee"
            });
        }


        if (results.length === 0) {

            return res.status(404).json({
                success: false,
                message: "Fee record not found"
            });
        }


        res.json({
            success: true,
            fee: results[0]
        });

    });

});


// =====================================
// ADD NEW FEE
// ADMIN / WARDEN ONLY
// =====================================

router.post("/", (req, res) => {

    // =====================================
    // STUDENT NOT ALLOWED
    // =====================================

    if (req.user.role === "STUDENT") {

        return res.status(403).json({
            success: false,
            message:
                "Students are not allowed to create fee records"
        });
    }


    const {
        student_id,
        fee_type,
        amount,
        due_date,
        paid_date,
        status
    } = req.body;


    // =====================================
    // VALIDATION
    // =====================================

    if (
        !student_id ||
        !fee_type ||
        amount === undefined ||
        !due_date
    ) {

        return res.status(400).json({
            success: false,
            message:
                "Please provide student_id, fee_type, amount and due_date"
        });
    }


    const sql = `
        INSERT INTO fees
        (
            student_id,
            fee_type,
            amount,
            due_date,
            paid_date,
            status
        )
        VALUES (?, ?, ?, ?, ?, ?)
    `;


    const values = [
        student_id,
        fee_type,
        amount,
        due_date,
        paid_date || null,
        status || "PENDING"
    ];


    db.query(sql, values, (err, result) => {

        if (err) {

            console.error("Error adding fee:", err);

            return res.status(500).json({
                success: false,
                message: "Failed to add fee",
                error: err.message
            });
        }


        res.status(201).json({
            success: true,
            message: "Fee added successfully!",
            fee_id: result.insertId
        });

    });

});


// =====================================
// UPDATE FEE
// ADMIN / WARDEN ONLY
// =====================================

router.put("/:id", (req, res) => {

    // =====================================
    // STUDENT NOT ALLOWED
    // =====================================

    if (req.user.role === "STUDENT") {

        return res.status(403).json({
            success: false,
            message:
                "Students are not allowed to update fee records"
        });
    }


    const feeId = req.params.id;

    const {
        student_id,
        fee_type,
        amount,
        due_date,
        paid_date,
        status
    } = req.body;


    // =====================================
    // VALIDATION
    // =====================================

    if (
        !student_id ||
        !fee_type ||
        amount === undefined ||
        !due_date
    ) {

        return res.status(400).json({
            success: false,
            message:
                "Please provide student_id, fee_type, amount and due_date"
        });
    }


    const sql = `
        UPDATE fees
        SET
            student_id = ?,
            fee_type = ?,
            amount = ?,
            due_date = ?,
            paid_date = ?,
            status = ?
        WHERE fee_id = ?
    `;


    const values = [
        student_id,
        fee_type,
        amount,
        due_date,
        paid_date || null,
        status || "PENDING",
        feeId
    ];


    db.query(sql, values, (err, result) => {

        if (err) {

            console.error("Error updating fee:", err);

            return res.status(500).json({
                success: false,
                message: "Failed to update fee",
                error: err.message
            });
        }


        if (result.affectedRows === 0) {

            return res.status(404).json({
                success: false,
                message: "Fee record not found"
            });
        }


        res.json({
            success: true,
            message: "Fee updated successfully!"
        });

    });

});


// =====================================
// MARK FEE AS PAID
// ADMIN / WARDEN ONLY
// =====================================

router.put("/:id/pay", (req, res) => {

    // =====================================
    // STUDENT NOT ALLOWED
    // =====================================

    if (req.user.role === "STUDENT") {

        return res.status(403).json({
            success: false,
            message:
                "Students are not allowed to update fee payment status"
        });
    }


    const feeId = req.params.id;

    const paidDate =
        req.body.paid_date ||
        new Date().toISOString().split("T")[0];


    const sql = `
        UPDATE fees
        SET
            paid_date = ?,
            status = "PAID"
        WHERE fee_id = ?
    `;


    db.query(
        sql,
        [paidDate, feeId],
        (err, result) => {

            if (err) {

                console.error("Error paying fee:", err);

                return res.status(500).json({
                    success: false,
                    message: "Failed to update payment"
                });
            }


            if (result.affectedRows === 0) {

                return res.status(404).json({
                    success: false,
                    message: "Fee record not found"
                });
            }


            res.json({
                success: true,
                message: "Fee marked as paid successfully!"
            });

        }
    );

});


// =====================================
// DELETE FEE
// ADMIN / WARDEN ONLY
// =====================================

router.delete("/:id", (req, res) => {

    // =====================================
    // STUDENT NOT ALLOWED
    // =====================================

    if (req.user.role === "STUDENT") {

        return res.status(403).json({
            success: false,
            message:
                "Students are not allowed to delete fee records"
        });
    }


    const feeId = req.params.id;


    const sql = `
        DELETE FROM fees
        WHERE fee_id = ?
    `;


    db.query(
        sql,
        [feeId],
        (err, result) => {

            if (err) {

                console.error("Error deleting fee:", err);

                return res.status(500).json({
                    success: false,
                    message: "Failed to delete fee",
                    error: err.message
                });
            }


            if (result.affectedRows === 0) {

                return res.status(404).json({
                    success: false,
                    message: "Fee record not found"
                });
            }


            res.json({
                success: true,
                message: "Fee deleted successfully!"
            });

        }
    );

});


module.exports = router;
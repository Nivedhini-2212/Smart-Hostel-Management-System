# Hostel Management System

A full-stack web-based Hostel Management System developed as a Software
Engineering mini project. The system provides role-based hostel
administration for **Administrators, Wardens, and Students**, with a
MySQL database, Node.js/Express backend, and React frontend.

------------------------------------------------------------------------

## 1. Project Overview

Managing hostel activities manually can make it difficult to maintain
student records, room and bed allocations, fee information, complaints,
leave requests, visitor details, and hostel notices.

The **Hostel Management System** provides a centralized digital platform
to manage these activities efficiently.

The system supports:

-   Student management
-   Hostel management
-   Room and bed management
-   Room/bed allocation
-   Fee management
-   Complaint management
-   Leave request management
-   Visitor management
-   Notice management
-   Role-based authentication and authorization
-   Separate dashboards for Admin, Warden, and Student

------------------------------------------------------------------------

## 2. Objectives

The main objectives of the project are:

1.  To digitize hostel management activities.
2.  To maintain student and hostel records in a centralized database.
3.  To manage rooms, beds, and student allocations efficiently.
4.  To allow students to access their own hostel-related information.
5.  To provide administrators and wardens with management facilities.
6.  To implement secure role-based access control.
7.  To reduce manual record keeping and improve information
    accessibility.

------------------------------------------------------------------------

## 3. User Roles

### Administrator

The Administrator has complete access to the hostel management system.

Main capabilities:

-   Manage students
-   Manage hostels
-   Manage rooms
-   Manage beds
-   Manage allocations
-   Manage fees
-   Manage complaints
-   Manage leave requests
-   Manage visitors
-   Manage notices
-   View dashboard statistics

### Warden

The Warden manages day-to-day hostel activities.

Main capabilities:

-   View and manage students
-   Manage hostels, rooms, and beds
-   Manage room allocations
-   Manage fees
-   Handle complaints
-   Approve/reject leave requests
-   Manage visitor records
-   Create and manage notices
-   View hostel statistics through the Warden Dashboard

### Student

Students have restricted access to their own information.

Main capabilities:

-   View personal profile
-   View own room/bed allocation
-   View own fees
-   Submit and view complaints
-   Submit and view leave requests
-   Manage/view own visitor records according to the implemented
    workflow
-   View hostel notices

Students cannot access administrative management functions.

------------------------------------------------------------------------

## 4. Major Modules

### 4.1 Authentication

The system provides:

-   Login using username and password
-   JWT-based authentication
-   Role-based authorization
-   Secure session handling using a JWT token
-   Logout functionality

### 4.2 Student Management

Administrators and wardens can:

-   Add students
-   Edit student information
-   Delete student records
-   Search/view student information

### 4.3 Hostel Management

The system maintains:

-   Hostel details
-   Hostel type
-   Hostel location
-   Number of rooms
-   Hostel status

### 4.4 Room Management

The room module manages:

-   Room numbers
-   Floors
-   Room capacity
-   Room status
-   Hostel association

### 4.5 Bed Management

The bed module manages:

-   Bed numbers
-   Room association
-   Bed availability
-   Occupied/available status

### 4.6 Room and Bed Allocation

The allocation module manages student accommodation.

The implemented workflow includes:

``` text
Student
   ↓
Room
   ↓
Available Bed
   ↓
Allocation
   ↓
Bed becomes OCCUPIED
   ↓
Student Dashboard
```

When an allocation is vacated:

``` text
Allocation
   ↓
Vacate
   ↓
Allocation becomes VACATED
   ↓
Bed becomes AVAILABLE
```

### 4.7 Fee Management

The fee module provides:

-   Fee records
-   Fee type
-   Amount
-   Due date
-   Payment date
-   Payment status

Administrators and wardens can manage fee records, while students can
view their own fees.

### 4.8 Complaint Management

Students can submit complaints.

Administrators and wardens can:

-   View complaints
-   Update complaints
-   Change complaint status
-   Resolve complaints

Students can only access their own complaints.

### 4.9 Leave Request Management

Students can submit leave requests with:

-   From date
-   To date
-   Reason

Administrators and wardens can review requests and approve or reject
them.

### 4.10 Visitor Management

Visitor records contain information such as:

-   Visitor name
-   Relationship
-   Phone number
-   Visit date
-   Entry time
-   Exit time
-   Status

Access is controlled according to the logged-in user's role.

### 4.11 Notice Management

Administrators and wardens can:

-   Create notices
-   Edit notices
-   Publish notices
-   Change notice status
-   Delete notices

Students have read-only access to notices.

Supported notice statuses:

``` text
DRAFT
PUBLISHED
EXPIRED
```

------------------------------------------------------------------------

## 5. Dashboards

### Admin Dashboard

Provides an overall view of hostel management information, including
counts and management modules.

### Warden Dashboard

Provides hostel-oriented information such as:

-   Total students
-   Total hostels
-   Total rooms
-   Available beds
-   Open complaints
-   Pending leave requests
-   Today's visitors
-   Pending fees
-   Accommodation status
-   Occupied/available beds
-   Active allocations
-   Recent notices

### Student Dashboard

Provides personalized information including:

-   Student profile
-   Current allocation
-   Fees
-   Complaints
-   Leave requests
-   Visitors
-   Notices
-   Quick actions

The Student Dashboard only requests student-specific information from
protected backend endpoints.

------------------------------------------------------------------------

## 6. Technology Stack

### Frontend

-   React
-   Vite
-   JavaScript
-   CSS
-   Lucide React icons

### Backend

-   Node.js
-   Express.js
-   MySQL2
-   JWT
-   bcryptjs
-   CORS
-   dotenv

### Database

-   MySQL 8.0

### Development Tools

-   Visual Studio Code
-   MySQL Workbench
-   Postman
-   Git/GitHub (optional)

------------------------------------------------------------------------

## 7. System Architecture

The project follows a three-tier architecture.

``` text
┌───────────────────────────────┐
│          FRONTEND             │
│      React + Vite + CSS       │
└───────────────┬───────────────┘
                │ HTTP / REST API
                ▼
┌───────────────────────────────┐
│           BACKEND             │
│      Node.js + Express        │
│ Authentication + Authorization│
│       REST API Routes         │
└───────────────┬───────────────┘
                │ SQL
                ▼
┌───────────────────────────────┐
│           DATABASE            │
│          MySQL 8.0            │
│       hostel_management       │
└───────────────────────────────┘
```

------------------------------------------------------------------------

## 8. Database

Database name:

``` text
hostel_management
```

The system contains the following major tables:

``` text
users
students
hostels
rooms
beds
room_allocations
fees
complaints
leave_requests
visitors
notices
```

Relationships are established using primary keys and foreign keys.

The database is designed to maintain consistency between:

-   Students
-   Users
-   Hostels
-   Rooms
-   Beds
-   Allocations
-   Fees
-   Complaints
-   Leave requests
-   Visitors
-   Notices

------------------------------------------------------------------------

## 9. Project Structure

``` text
Hostel-Management-System/
│
├── backend/
│   ├── config/
│   │   └── db.js
│   │
│   ├── middleware/
│   │   └── authMiddleware.js
│   │
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── profileRoutes.js
│   │   ├── studentRoutes.js
│   │   ├── hostelRoutes.js
│   │   ├── roomRoutes.js
│   │   ├── bedRoutes.js
│   │   ├── allocationRoutes.js
│   │   ├── feeRoutes.js
│   │   ├── complaintRoutes.js
│   │   ├── leaveRoutes.js
│   │   ├── visitorRoutes.js
│   │   └── noticeRoutes.js
│   │
│   ├── controllers/
│   ├── package.json
│   └── server.js
│
├── database/
│   ├── schema.sql
│   └── sample_data.sql
│
├── Documentation/
│   ├── 01_Project_Overview.docx
│   ├── 02_SRS.docx
│   ├── 03_Database_Design.docx
│   └── 04_ER_Diagram/
│
└── frontend/
    └── Hostel-Management-System-frontend/
        ├── src/
        ├── package.json
        ├── index.html
        └── README.md
```

------------------------------------------------------------------------

## 10. Installation and Setup

### Prerequisites

Install the following:

-   Node.js
-   npm
-   MySQL Server
-   MySQL Workbench
-   Web browser

------------------------------------------------------------------------

### Step 1: Create the Database

Open MySQL Workbench and create:

``` sql
CREATE DATABASE hostel_management;
```

Import/run the project's SQL files from the `database` folder.

------------------------------------------------------------------------

### Step 2: Configure Database Connection

Open:

``` text
backend/config/db.js
```

Configure the MySQL connection according to the local MySQL
installation.

Example:

``` js
const mysql = require('mysql2');

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'YOUR_MYSQL_PASSWORD',
    database: 'hostel_management',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

module.exports = db;
```

Do not commit real database passwords to a public repository.

------------------------------------------------------------------------

### Step 3: Install Backend Dependencies

Open Command Prompt:

``` bat
cd C:\Users\<username>\OneDrive\Documents\Hostel-Management-System\backend
npm install
```

------------------------------------------------------------------------

### Step 4: Start Backend

``` bat
node server.js
```

The backend runs at:

``` text
http://localhost:5000
```

------------------------------------------------------------------------

### Step 5: Install Frontend Dependencies

Open another Command Prompt:

``` bat
cd C:\Users\<username>\OneDrive\Documents\Hostel-Management-System\frontend\Hostel-Management-System-frontend
npm install
```

------------------------------------------------------------------------

### Step 6: Start Frontend

``` bat
npm run dev
```

The frontend will normally be available at:

``` text
http://localhost:5173
```

------------------------------------------------------------------------

## 11. Authentication

The application uses JWT-based authentication.

After successful login:

``` text
Username + Password
        ↓
Backend Authentication
        ↓
JWT Token
        ↓
Frontend stores token
        ↓
Token sent with protected API requests
        ↓
Backend verifies token
        ↓
Role authorization
        ↓
Requested resource
```

Protected APIs require:

``` text
Authorization: Bearer <JWT_TOKEN>
```

------------------------------------------------------------------------

## 12. Role-Based Security

Backend authorization is implemented in addition to frontend module
restrictions.

This means hiding a module from the frontend is not the only security
mechanism.

For example:

``` text
Student
   ↓
Attempts to access /api/students
   ↓
JWT verification
   ↓
Role verification
   ↓
403 Forbidden
```

Student-specific resources are also filtered using the authenticated
user's identity.

Therefore, a student cannot simply change a `student_id` value in a
request to access another student's records.

------------------------------------------------------------------------

## 13. API Base URL

``` text
http://localhost:5000/api
```

Main API groups:

``` text
/api/auth
/api/profile
/api/students
/api/hostels
/api/rooms
/api/beds
/api/allocations
/api/fees
/api/complaints
/api/leave
/api/visitors
/api/notices
```

------------------------------------------------------------------------

## 14. Test Accounts

For local development/testing, the project contains role-based accounts.

### Administrator

``` text
Username: admin
Password: admin123
Role: ADMIN
```

### Warden

``` text
Username: warden1
Password: warden123
Role: WARDEN
```

### Student

``` text
Username: student1
Password: student123
Role: STUDENT
```

> These credentials are intended for local project demonstration. Change
> them before deploying the application to a real environment.

------------------------------------------------------------------------

## 15. Current Project Status

The current version implements the core Hostel Management System
functionality.

### Completed

-   [x] MySQL database
-   [x] Database tables and relationships
-   [x] React frontend
-   [x] Node.js/Express backend
-   [x] JWT authentication
-   [x] Role-based authorization
-   [x] Admin Dashboard
-   [x] Warden Dashboard
-   [x] Student Dashboard
-   [x] Student management
-   [x] Hostel management
-   [x] Room management
-   [x] Bed management
-   [x] Room/bed allocation
-   [x] Fee management
-   [x] Complaint management
-   [x] Leave request management
-   [x] Visitor management
-   [x] Notice management
-   [x] Student data isolation
-   [x] Protected backend APIs
-   [x] CRUD operations for major modules
-   [x] Responsive frontend structure
-   [x] Project documentation

------------------------------------------------------------------------

# 16. Future Developments

The current system can be further enhanced with the following
functionalities.

### 16.1 Online Fee Payment

Integrate a payment gateway so students can pay hostel fees online.

Possible features:

-   Online payment
-   Payment confirmation
-   Transaction ID
-   Digital receipts
-   Payment history

### 16.2 Email and SMS Notifications

Automated notifications can be added for:

-   Fee due dates
-   Leave approval/rejection
-   Complaint updates
-   New hostel notices
-   Visitor approvals
-   Allocation changes

### 16.3 Advanced Search and Filtering

Add advanced filters for:

-   Department
-   Year
-   Hostel
-   Room
-   Gender
-   Student status
-   Fee status
-   Complaint status
-   Leave status

### 16.4 Hostel Occupancy Analytics

Introduce charts and reports for:

-   Hostel occupancy
-   Room occupancy
-   Bed availability
-   Student distribution
-   Fee collection
-   Complaint statistics

### 16.5 Automated Room Allocation

A future version can automatically assign rooms/beds based on:

-   Hostel availability
-   Room capacity
-   Student preferences
-   Department/year
-   Special requirements

### 16.6 Digital Visitor Pass

Generate a digital visitor pass containing:

-   Visitor information
-   Student information
-   Visit date
-   Entry time
-   QR code

### 16.7 QR-Based Hostel Services

QR codes can be introduced for:

-   Visitor verification
-   Student identification
-   Room/bed identification
-   Complaint submission
-   Hostel announcements

### 16.8 Maintenance Management

A dedicated maintenance module can manage:

-   Electrical problems
-   Plumbing issues
-   Furniture damage
-   Cleaning requests
-   Maintenance assignments
-   Maintenance status

### 16.9 Mess Management

Future versions can include:

-   Mess attendance
-   Daily menu
-   Food feedback
-   Mess fee management
-   Meal preferences

### 16.10 Attendance Management

Hostel attendance functionality can be added for:

-   Daily hostel attendance
-   Out-pass tracking
-   Late return tracking
-   Attendance reports

### 16.11 Advanced Reporting

Generate downloadable reports such as:

-   Student reports
-   Occupancy reports
-   Fee reports
-   Complaint reports
-   Leave reports
-   Visitor reports

Reports can eventually be exported as PDF or Excel files.

### 16.12 Password and Account Management

Future improvements can include:

-   Change password
-   Forgot password
-   Password reset through email/OTP
-   Account verification
-   Improved password policies

### 16.13 Production Deployment

The application can eventually be deployed using:

-   Cloud database
-   Cloud backend
-   Cloud frontend
-   HTTPS
-   Environment variables
-   Production-grade authentication
-   Database backups

------------------------------------------------------------------------

## 17. Limitations of Current Version

The current version focuses on the core hostel management workflow and
academic project requirements.

Some advanced real-world features such as online payment gateways,
automated notifications, advanced analytics, QR-based services, mess
management, maintenance management, and cloud deployment are planned as
future enhancements.

These features can be incorporated in later versions without changing
the core architecture of the system.

------------------------------------------------------------------------

## 18. Future Scope

The Hostel Management System can be extended into a complete smart
hostel management platform by integrating:

``` text
Hostel Management
       +
Online Payments
       +
Notifications
       +
Analytics
       +
QR Services
       +
Mess Management
       +
Maintenance
       +
Mobile Application
       +
Cloud Deployment
```

This can make the system suitable for larger educational institutions
with multiple hostels and a larger number of students.

------------------------------------------------------------------------

## 19. Conclusion

The Hostel Management System provides a centralized platform for
managing essential hostel operations.

The implemented system demonstrates:

-   Full-stack application development
-   Database management
-   REST API development
-   Authentication
-   Role-based authorization
-   CRUD operations
-   Data isolation
-   Dashboard-based management

The current implementation is suitable as an academic Software
Engineering project and provides a strong foundation for future
enhancements.

------------------------------------------------------------------------

## 20. Authors

**Department of Information Technology**

**B.Tech Information Technology**

**Hostel Management System -- Software Engineering Mini Project**

------------------------------------------------------------------------

## License

This project is developed for academic and educational purposes.
